--
-- PostgreSQL database dump
--

\restrict f95Ud05VRJkckMDJPsWlFb08z6U4sRb9rsLsdFf5VL0SISIhKw5S03Mhj1cUzQY

-- Dumped from database version 15.16 (Debian 15.16-0+deb12u1)
-- Dumped by pg_dump version 15.16 (Debian 15.16-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_logs; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.admin_logs (
    id integer NOT NULL,
    admin_wallet text NOT NULL,
    action text NOT NULL,
    target text,
    detail jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.admin_logs OWNER TO roon_user;

--
-- Name: admin_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.admin_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_logs_id_seq OWNER TO roon_user;

--
-- Name: admin_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.admin_logs_id_seq OWNED BY public.admin_logs.id;


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcements (
    id integer NOT NULL,
    content text NOT NULL,
    type character varying(20) DEFAULT 'info'::character varying,
    active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.announcements OWNER TO postgres;

--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.announcements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.announcements_id_seq OWNER TO postgres;

--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: ascension_perks; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.ascension_perks (
    id integer NOT NULL,
    ascension_level integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    attack_bonus double precision DEFAULT 0,
    defense_bonus double precision DEFAULT 0,
    health_bonus double precision DEFAULT 0,
    speed_bonus double precision DEFAULT 0,
    cultivation_speed_bonus double precision DEFAULT 0,
    special_perk text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ascension_perks OWNER TO roon_user;

--
-- Name: ascension_perks_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.ascension_perks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ascension_perks_id_seq OWNER TO roon_user;

--
-- Name: ascension_perks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.ascension_perks_id_seq OWNED BY public.ascension_perks.id;


--
-- Name: ascension_records; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.ascension_records (
    id integer NOT NULL,
    wallet character varying(255) NOT NULL,
    ascension_count integer DEFAULT 1 NOT NULL,
    previous_level integer DEFAULT 100 NOT NULL,
    bonuses jsonb DEFAULT '{}'::jsonb,
    ascended_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ascension_records OWNER TO roon_user;

--
-- Name: ascension_records_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.ascension_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ascension_records_id_seq OWNER TO roon_user;

--
-- Name: ascension_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.ascension_records_id_seq OWNED BY public.ascension_records.id;


--
-- Name: auction_bids; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.auction_bids (
    id integer NOT NULL,
    listing_id integer NOT NULL,
    bidder_wallet character varying(255) NOT NULL,
    bidder_name character varying(255),
    bid_amount integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.auction_bids OWNER TO roon_user;

--
-- Name: auction_bids_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.auction_bids_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auction_bids_id_seq OWNER TO roon_user;

--
-- Name: auction_bids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.auction_bids_id_seq OWNED BY public.auction_bids.id;


--
-- Name: auction_history; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.auction_history (
    id integer NOT NULL,
    listing_id integer,
    seller_wallet character varying(255),
    buyer_wallet character varying(255),
    item_name character varying(255),
    item_type character varying(50),
    item_quality character varying(50),
    final_price integer,
    sold_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.auction_history OWNER TO roon_user;

--
-- Name: auction_history_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.auction_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auction_history_id_seq OWNER TO roon_user;

--
-- Name: auction_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.auction_history_id_seq OWNED BY public.auction_history.id;


--
-- Name: auction_listings; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.auction_listings (
    id integer NOT NULL,
    seller_wallet character varying(255) NOT NULL,
    seller_name character varying(255),
    item_data jsonb NOT NULL,
    item_name character varying(255) NOT NULL,
    item_type character varying(50) NOT NULL,
    item_quality character varying(50) NOT NULL,
    starting_price integer NOT NULL,
    buyout_price integer,
    current_bid integer DEFAULT 0,
    current_bidder character varying(255),
    bid_count integer DEFAULT 0,
    duration_hours integer NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.auction_listings OWNER TO roon_user;

--
-- Name: auction_listings_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.auction_listings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auction_listings_id_seq OWNER TO roon_user;

--
-- Name: auction_listings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.auction_listings_id_seq OWNED BY public.auction_listings.id;


--
-- Name: boss_damage_log; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.boss_damage_log (
    id integer NOT NULL,
    boss_id integer,
    wallet character varying(100) NOT NULL,
    player_name character varying(100) DEFAULT '无名修士'::character varying,
    damage bigint DEFAULT 0,
    attacks_count integer DEFAULT 0,
    last_attack_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.boss_damage_log OWNER TO roon_user;

--
-- Name: boss_damage_log_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.boss_damage_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.boss_damage_log_id_seq OWNER TO roon_user;

--
-- Name: boss_damage_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.boss_damage_log_id_seq OWNED BY public.boss_damage_log.id;


--
-- Name: boss_rewards; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.boss_rewards (
    id integer NOT NULL,
    boss_id integer,
    wallet character varying(100) NOT NULL,
    rank integer DEFAULT 0,
    reward_stones integer DEFAULT 0,
    reward_items jsonb DEFAULT '[]'::jsonb,
    claimed boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.boss_rewards OWNER TO roon_user;

--
-- Name: boss_rewards_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.boss_rewards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.boss_rewards_id_seq OWNER TO roon_user;

--
-- Name: boss_rewards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.boss_rewards_id_seq OWNED BY public.boss_rewards.id;


--
-- Name: daily_dungeon_entries; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.daily_dungeon_entries (
    id integer NOT NULL,
    dungeon_id integer NOT NULL,
    wallet character varying(42) NOT NULL,
    player_name character varying(50),
    result character varying(20) DEFAULT 'defeat'::character varying NOT NULL,
    rewards_earned jsonb DEFAULT '{}'::jsonb,
    entry_date date DEFAULT CURRENT_DATE NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.daily_dungeon_entries OWNER TO roon_user;

--
-- Name: daily_dungeon_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.daily_dungeon_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.daily_dungeon_entries_id_seq OWNER TO roon_user;

--
-- Name: daily_dungeon_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.daily_dungeon_entries_id_seq OWNED BY public.daily_dungeon_entries.id;


--
-- Name: daily_dungeons; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.daily_dungeons (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    difficulty character varying(20) DEFAULT 'easy'::character varying NOT NULL,
    min_level integer DEFAULT 1 NOT NULL,
    max_entries integer DEFAULT 3 NOT NULL,
    enemy_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    rewards_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.daily_dungeons OWNER TO roon_user;

--
-- Name: daily_dungeons_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.daily_dungeons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.daily_dungeons_id_seq OWNER TO roon_user;

--
-- Name: daily_dungeons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.daily_dungeons_id_seq OWNED BY public.daily_dungeons.id;


--
-- Name: equipment; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.equipment (
    id integer NOT NULL,
    owner_id integer NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50),
    slot character varying(50),
    quality character varying(50) DEFAULT 'common'::character varying,
    level integer DEFAULT 1,
    required_realm integer DEFAULT 0,
    stats jsonb DEFAULT '{}'::jsonb,
    is_equipped boolean DEFAULT false,
    equipped_slot character varying(50),
    enhance_level integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.equipment OWNER TO roon_user;

--
-- Name: equipment_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.equipment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.equipment_id_seq OWNER TO roon_user;

--
-- Name: equipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.equipment_id_seq OWNED BY public.equipment.id;


--
-- Name: event_claims; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_claims (
    id integer NOT NULL,
    event_id integer,
    wallet character varying(42) NOT NULL,
    claimed_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.event_claims OWNER TO postgres;

--
-- Name: event_claims_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.event_claims_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_claims_id_seq OWNER TO postgres;

--
-- Name: event_claims_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.event_claims_id_seq OWNED BY public.event_claims.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(30) NOT NULL,
    config jsonb DEFAULT '{}'::jsonb,
    starts_at timestamp without time zone NOT NULL,
    ends_at timestamp without time zone NOT NULL,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    description text DEFAULT ''::text,
    rewards jsonb DEFAULT '[]'::jsonb
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_id_seq OWNER TO postgres;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: friend_gifts; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.friend_gifts (
    id integer NOT NULL,
    from_wallet character varying(42) NOT NULL,
    to_wallet character varying(42) NOT NULL,
    gift_type character varying(30) DEFAULT 'spirit_stones'::character varying,
    gift_value integer DEFAULT 0,
    message text DEFAULT ''::text,
    claimed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.friend_gifts OWNER TO roon_user;

--
-- Name: friend_gifts_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.friend_gifts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.friend_gifts_id_seq OWNER TO roon_user;

--
-- Name: friend_gifts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.friend_gifts_id_seq OWNED BY public.friend_gifts.id;


--
-- Name: friendships; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.friendships (
    id integer NOT NULL,
    from_wallet character varying(42) NOT NULL,
    to_wallet character varying(42) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.friendships OWNER TO roon_user;

--
-- Name: friendships_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.friendships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.friendships_id_seq OWNER TO roon_user;

--
-- Name: friendships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.friendships_id_seq OWNED BY public.friendships.id;


--
-- Name: leaderboard_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leaderboard_cache (
    id integer NOT NULL,
    type character varying(20) NOT NULL,
    data jsonb DEFAULT '[]'::jsonb,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.leaderboard_cache OWNER TO postgres;

--
-- Name: leaderboard_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.leaderboard_cache_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.leaderboard_cache_id_seq OWNER TO postgres;

--
-- Name: leaderboard_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.leaderboard_cache_id_seq OWNED BY public.leaderboard_cache.id;


--
-- Name: monthly_cards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monthly_cards (
    id integer NOT NULL,
    wallet character varying(42) NOT NULL,
    purchased_at timestamp without time zone DEFAULT now(),
    expires_at timestamp without time zone NOT NULL,
    last_claim_date date,
    days_claimed integer DEFAULT 0
);


ALTER TABLE public.monthly_cards OWNER TO postgres;

--
-- Name: monthly_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.monthly_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.monthly_cards_id_seq OWNER TO postgres;

--
-- Name: monthly_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.monthly_cards_id_seq OWNED BY public.monthly_cards.id;


--
-- Name: mounts; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.mounts (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    quality character varying(20) DEFAULT 'common'::character varying,
    emoji character varying(10),
    attack_bonus double precision DEFAULT 0,
    defense_bonus double precision DEFAULT 0,
    health_bonus double precision DEFAULT 0,
    speed_bonus double precision DEFAULT 0,
    special_effect text,
    obtain_method text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.mounts OWNER TO roon_user;

--
-- Name: mounts_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.mounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mounts_id_seq OWNER TO roon_user;

--
-- Name: mounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.mounts_id_seq OWNED BY public.mounts.id;


--
-- Name: pets; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.pets (
    id integer NOT NULL,
    owner_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    rarity character varying(50) DEFAULT 'mortal'::character varying,
    level integer DEFAULT 1,
    star integer DEFAULT 0,
    combat_attributes jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.pets OWNER TO roon_user;

--
-- Name: pets_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.pets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pets_id_seq OWNER TO roon_user;

--
-- Name: pets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.pets_id_seq OWNED BY public.pets.id;


--
-- Name: pk_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pk_records (
    id integer NOT NULL,
    wallet_a character varying(42) NOT NULL,
    wallet_b character varying(42) NOT NULL,
    name_a character varying(50),
    name_b character varying(50),
    winner character(1),
    winner_wallet character varying(42),
    rounds_data jsonb DEFAULT '[]'::jsonb,
    reward integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.pk_records OWNER TO postgres;

--
-- Name: pk_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pk_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pk_records_id_seq OWNER TO postgres;

--
-- Name: pk_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pk_records_id_seq OWNED BY public.pk_records.id;


--
-- Name: player_mail; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.player_mail (
    id integer NOT NULL,
    to_wallet character varying(42) NOT NULL,
    from_type character varying(20) DEFAULT 'system'::character varying NOT NULL,
    from_name character varying(50) DEFAULT '系统'::character varying,
    title character varying(100) NOT NULL,
    content text NOT NULL,
    rewards jsonb DEFAULT '{}'::jsonb,
    is_read boolean DEFAULT false,
    is_claimed boolean DEFAULT false,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.player_mail OWNER TO roon_user;

--
-- Name: player_mail_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.player_mail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.player_mail_id_seq OWNER TO roon_user;

--
-- Name: player_mail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.player_mail_id_seq OWNED BY public.player_mail.id;


--
-- Name: player_mounts; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.player_mounts (
    id integer NOT NULL,
    wallet character varying(100) NOT NULL,
    mount_id integer,
    level integer DEFAULT 1,
    exp integer DEFAULT 0,
    is_active boolean DEFAULT false,
    obtained_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.player_mounts OWNER TO roon_user;

--
-- Name: player_mounts_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.player_mounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.player_mounts_id_seq OWNER TO roon_user;

--
-- Name: player_mounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.player_mounts_id_seq OWNED BY public.player_mounts.id;


--
-- Name: player_titles; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.player_titles (
    id integer NOT NULL,
    wallet character varying(100) NOT NULL,
    title_id integer,
    is_active boolean DEFAULT false,
    obtained_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.player_titles OWNER TO roon_user;

--
-- Name: player_titles_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.player_titles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.player_titles_id_seq OWNER TO roon_user;

--
-- Name: player_titles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.player_titles_id_seq OWNED BY public.player_titles.id;


--
-- Name: players; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.players (
    id integer NOT NULL,
    wallet character varying(42) NOT NULL,
    name character varying(50) DEFAULT '无名修士'::character varying,
    game_data jsonb DEFAULT '{}'::jsonb,
    vip_level integer DEFAULT 0,
    total_recharge numeric(20,8) DEFAULT 0,
    spirit_stones bigint DEFAULT 0,
    level integer DEFAULT 1,
    realm character varying(50) DEFAULT '燃火期一层'::character varying,
    combat_power bigint DEFAULT 0,
    first_recharge boolean DEFAULT false,
    daily_sign_date date,
    daily_sign_streak integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    banned boolean DEFAULT false
);


ALTER TABLE public.players OWNER TO postgres;

--
-- Name: players_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.players_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.players_id_seq OWNER TO postgres;

--
-- Name: players_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.players_id_seq OWNED BY public.players.id;


--
-- Name: private_messages; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.private_messages (
    id integer NOT NULL,
    from_wallet character varying(42) NOT NULL,
    to_wallet character varying(42) NOT NULL,
    content text NOT NULL,
    is_read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.private_messages OWNER TO roon_user;

--
-- Name: private_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.private_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.private_messages_id_seq OWNER TO roon_user;

--
-- Name: private_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.private_messages_id_seq OWNED BY public.private_messages.id;


--
-- Name: recharge_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recharge_log (
    id integer NOT NULL,
    wallet character varying(42) NOT NULL,
    tx_hash character varying(66) NOT NULL,
    amount numeric(20,8) NOT NULL,
    spirit_stones bigint NOT NULL,
    bonus_stones bigint DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.recharge_log OWNER TO postgres;

--
-- Name: recharge_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recharge_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recharge_log_id_seq OWNER TO postgres;

--
-- Name: recharge_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recharge_log_id_seq OWNED BY public.recharge_log.id;


--
-- Name: sect_members; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.sect_members (
    id integer NOT NULL,
    sect_id integer,
    wallet character varying(100) NOT NULL,
    role character varying(20) DEFAULT 'member'::character varying,
    contribution bigint DEFAULT 0,
    joined_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sect_members OWNER TO roon_user;

--
-- Name: sect_members_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.sect_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sect_members_id_seq OWNER TO roon_user;

--
-- Name: sect_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.sect_members_id_seq OWNED BY public.sect_members.id;


--
-- Name: sect_tasks; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.sect_tasks (
    id integer NOT NULL,
    sect_id integer,
    type character varying(10) DEFAULT 'daily'::character varying,
    title character varying(100) NOT NULL,
    description text DEFAULT ''::text,
    reward_contribution integer DEFAULT 10,
    reward_stones integer DEFAULT 100,
    completed_by jsonb DEFAULT '[]'::jsonb,
    reset_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sect_tasks OWNER TO roon_user;

--
-- Name: sect_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.sect_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sect_tasks_id_seq OWNER TO roon_user;

--
-- Name: sect_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.sect_tasks_id_seq OWNED BY public.sect_tasks.id;


--
-- Name: sect_war_participants; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.sect_war_participants (
    id integer NOT NULL,
    war_id integer NOT NULL,
    sect_id integer NOT NULL,
    wallet character varying(255) NOT NULL,
    player_name character varying(100),
    combat_power bigint DEFAULT 0,
    result character varying(10) DEFAULT 'pending'::character varying,
    damage_dealt bigint DEFAULT 0,
    round_number integer
);


ALTER TABLE public.sect_war_participants OWNER TO roon_user;

--
-- Name: sect_war_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.sect_war_participants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sect_war_participants_id_seq OWNER TO roon_user;

--
-- Name: sect_war_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.sect_war_participants_id_seq OWNED BY public.sect_war_participants.id;


--
-- Name: sect_war_rankings; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.sect_war_rankings (
    id integer NOT NULL,
    sect_id integer NOT NULL,
    season integer DEFAULT 1,
    wins integer DEFAULT 0,
    losses integer DEFAULT 0,
    points integer DEFAULT 0,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sect_war_rankings OWNER TO roon_user;

--
-- Name: sect_war_rankings_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.sect_war_rankings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sect_war_rankings_id_seq OWNER TO roon_user;

--
-- Name: sect_war_rankings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.sect_war_rankings_id_seq OWNED BY public.sect_war_rankings.id;


--
-- Name: sect_war_rewards; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.sect_war_rewards (
    id integer NOT NULL,
    war_id integer NOT NULL,
    sect_id integer NOT NULL,
    wallet character varying(255) NOT NULL,
    reward_stones integer DEFAULT 0,
    reward_contribution integer DEFAULT 0,
    claimed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sect_war_rewards OWNER TO roon_user;

--
-- Name: sect_war_rewards_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.sect_war_rewards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sect_war_rewards_id_seq OWNER TO roon_user;

--
-- Name: sect_war_rewards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.sect_war_rewards_id_seq OWNED BY public.sect_war_rewards.id;


--
-- Name: sect_wars; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.sect_wars (
    id integer NOT NULL,
    challenger_sect_id integer NOT NULL,
    defender_sect_id integer NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    challenger_score integer DEFAULT 0,
    defender_score integer DEFAULT 0,
    winner_sect_id integer,
    rounds_data jsonb,
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sect_wars OWNER TO roon_user;

--
-- Name: sect_wars_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.sect_wars_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sect_wars_id_seq OWNER TO roon_user;

--
-- Name: sect_wars_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.sect_wars_id_seq OWNED BY public.sect_wars.id;


--
-- Name: sects; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.sects (
    id integer NOT NULL,
    name character varying(30) NOT NULL,
    description text DEFAULT ''::text,
    leader_wallet character varying(100) NOT NULL,
    level integer DEFAULT 1,
    exp bigint DEFAULT 0,
    max_members integer DEFAULT 20,
    announcement text DEFAULT '欢迎加入本宗门！'::text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sects OWNER TO roon_user;

--
-- Name: sects_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.sects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sects_id_seq OWNER TO roon_user;

--
-- Name: sects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.sects_id_seq OWNED BY public.sects.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.settings (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.settings OWNER TO roon_user;

--
-- Name: titles; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.titles (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    quality character varying(20) DEFAULT 'common'::character varying,
    color character varying(20),
    condition_type character varying(50),
    condition_value integer,
    attack_bonus double precision DEFAULT 0,
    defense_bonus double precision DEFAULT 0,
    health_bonus double precision DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.titles OWNER TO roon_user;

--
-- Name: titles_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.titles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.titles_id_seq OWNER TO roon_user;

--
-- Name: titles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.titles_id_seq OWNED BY public.titles.id;


--
-- Name: world_bosses; Type: TABLE; Schema: public; Owner: roon_user
--

CREATE TABLE public.world_bosses (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    level integer DEFAULT 1,
    max_hp bigint NOT NULL,
    current_hp bigint NOT NULL,
    attack integer DEFAULT 100,
    defense integer DEFAULT 50,
    description text DEFAULT ''::text,
    rewards_config jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'waiting'::character varying,
    spawn_time timestamp with time zone,
    death_time timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.world_bosses OWNER TO roon_user;

--
-- Name: world_bosses_id_seq; Type: SEQUENCE; Schema: public; Owner: roon_user
--

CREATE SEQUENCE public.world_bosses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.world_bosses_id_seq OWNER TO roon_user;

--
-- Name: world_bosses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roon_user
--

ALTER SEQUENCE public.world_bosses_id_seq OWNED BY public.world_bosses.id;


--
-- Name: admin_logs id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.admin_logs ALTER COLUMN id SET DEFAULT nextval('public.admin_logs_id_seq'::regclass);


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: ascension_perks id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.ascension_perks ALTER COLUMN id SET DEFAULT nextval('public.ascension_perks_id_seq'::regclass);


--
-- Name: ascension_records id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.ascension_records ALTER COLUMN id SET DEFAULT nextval('public.ascension_records_id_seq'::regclass);


--
-- Name: auction_bids id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.auction_bids ALTER COLUMN id SET DEFAULT nextval('public.auction_bids_id_seq'::regclass);


--
-- Name: auction_history id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.auction_history ALTER COLUMN id SET DEFAULT nextval('public.auction_history_id_seq'::regclass);


--
-- Name: auction_listings id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.auction_listings ALTER COLUMN id SET DEFAULT nextval('public.auction_listings_id_seq'::regclass);


--
-- Name: boss_damage_log id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.boss_damage_log ALTER COLUMN id SET DEFAULT nextval('public.boss_damage_log_id_seq'::regclass);


--
-- Name: boss_rewards id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.boss_rewards ALTER COLUMN id SET DEFAULT nextval('public.boss_rewards_id_seq'::regclass);


--
-- Name: daily_dungeon_entries id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.daily_dungeon_entries ALTER COLUMN id SET DEFAULT nextval('public.daily_dungeon_entries_id_seq'::regclass);


--
-- Name: daily_dungeons id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.daily_dungeons ALTER COLUMN id SET DEFAULT nextval('public.daily_dungeons_id_seq'::regclass);


--
-- Name: equipment id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.equipment ALTER COLUMN id SET DEFAULT nextval('public.equipment_id_seq'::regclass);


--
-- Name: event_claims id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_claims ALTER COLUMN id SET DEFAULT nextval('public.event_claims_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: friend_gifts id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.friend_gifts ALTER COLUMN id SET DEFAULT nextval('public.friend_gifts_id_seq'::regclass);


--
-- Name: friendships id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.friendships ALTER COLUMN id SET DEFAULT nextval('public.friendships_id_seq'::regclass);


--
-- Name: leaderboard_cache id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard_cache ALTER COLUMN id SET DEFAULT nextval('public.leaderboard_cache_id_seq'::regclass);


--
-- Name: monthly_cards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_cards ALTER COLUMN id SET DEFAULT nextval('public.monthly_cards_id_seq'::regclass);


--
-- Name: mounts id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.mounts ALTER COLUMN id SET DEFAULT nextval('public.mounts_id_seq'::regclass);


--
-- Name: pets id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.pets ALTER COLUMN id SET DEFAULT nextval('public.pets_id_seq'::regclass);


--
-- Name: pk_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pk_records ALTER COLUMN id SET DEFAULT nextval('public.pk_records_id_seq'::regclass);


--
-- Name: player_mail id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.player_mail ALTER COLUMN id SET DEFAULT nextval('public.player_mail_id_seq'::regclass);


--
-- Name: player_mounts id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.player_mounts ALTER COLUMN id SET DEFAULT nextval('public.player_mounts_id_seq'::regclass);


--
-- Name: player_titles id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.player_titles ALTER COLUMN id SET DEFAULT nextval('public.player_titles_id_seq'::regclass);


--
-- Name: players id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players ALTER COLUMN id SET DEFAULT nextval('public.players_id_seq'::regclass);


--
-- Name: private_messages id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.private_messages ALTER COLUMN id SET DEFAULT nextval('public.private_messages_id_seq'::regclass);


--
-- Name: recharge_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recharge_log ALTER COLUMN id SET DEFAULT nextval('public.recharge_log_id_seq'::regclass);


--
-- Name: sect_members id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_members ALTER COLUMN id SET DEFAULT nextval('public.sect_members_id_seq'::regclass);


--
-- Name: sect_tasks id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_tasks ALTER COLUMN id SET DEFAULT nextval('public.sect_tasks_id_seq'::regclass);


--
-- Name: sect_war_participants id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_war_participants ALTER COLUMN id SET DEFAULT nextval('public.sect_war_participants_id_seq'::regclass);


--
-- Name: sect_war_rankings id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_war_rankings ALTER COLUMN id SET DEFAULT nextval('public.sect_war_rankings_id_seq'::regclass);


--
-- Name: sect_war_rewards id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_war_rewards ALTER COLUMN id SET DEFAULT nextval('public.sect_war_rewards_id_seq'::regclass);


--
-- Name: sect_wars id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_wars ALTER COLUMN id SET DEFAULT nextval('public.sect_wars_id_seq'::regclass);


--
-- Name: sects id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sects ALTER COLUMN id SET DEFAULT nextval('public.sects_id_seq'::regclass);


--
-- Name: titles id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.titles ALTER COLUMN id SET DEFAULT nextval('public.titles_id_seq'::regclass);


--
-- Name: world_bosses id; Type: DEFAULT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.world_bosses ALTER COLUMN id SET DEFAULT nextval('public.world_bosses_id_seq'::regclass);


--
-- Data for Name: admin_logs; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.admin_logs (id, admin_wallet, action, target, detail, created_at) FROM stdin;
1	0xfad7eb0814b6838b05191a07fb987957d50c4ca9	delete_announcement	3	{}	2026-02-18 11:02:31.157106-05
2	0xfad7eb0814b6838b05191a07fb987957d50c4ca9	delete_announcement	2	{}	2026-02-18 11:02:32.980928-05
3	0xfad7eb0814b6838b05191a07fb987957d50c4ca9	delete_announcement	1	{}	2026-02-18 11:02:35.901093-05
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcements (id, content, type, active, sort_order, created_at) FROM stdin;
4	🔥 火之文明：焰修传说 正式上线！欢迎各位焰修者！	info	t	1	2026-02-21 04:17:15.126291
5	⚔️ 黑焰入侵已开启，击败远古妖龙可获珍稀坐骑！	event	t	2	2026-02-21 04:17:15.126291
6	💎 首充双倍焰晶活动进行中，充值即享超值回馈！	promo	t	3	2026-02-21 04:17:15.126291
\.


--
-- Data for Name: ascension_perks; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.ascension_perks (id, ascension_level, name, description, attack_bonus, defense_bonus, health_bonus, speed_bonus, cultivation_speed_bonus, special_perk, created_at) FROM stdin;
1	1	初次涅槃	浴火重生，焰力觉醒。基础属性永久+10%	0.1	0.1	0.1	0.1	0.1	解锁飞升商店	2026-02-18 07:36:02.397441
2	2	二次涅槃	焰心坚固，焰力更进。基础属性永久+25%	0.25	0.25	0.25	0.25	0.2	抽卡保底-10次	2026-02-18 07:36:02.397441
3	3	三次涅槃	天焰感应，万法归一。基础属性永久+50%	0.5	0.5	0.5	0.5	0.35	每日副本+1次	2026-02-18 07:36:02.397441
4	4	四次涅槃	超凡入圣，不灭焰体。基础属性永久+80%	0.8	0.8	0.8	0.8	0.5	秘境起始+10层	2026-02-18 07:36:02.397441
5	5	五次涅槃	大道至简，焰人合一。基础属性永久+120%	1.2	1.2	1.2	1.2	0.75	解锁鲲鹏坐骑	2026-02-18 07:36:02.397441
6	6	六次涅槃	混元永焰，永恒不灭。基础属性永久+170%	1.7	1.7	1.7	1.7	1	全属性翻倍	2026-02-18 07:36:02.397441
7	7	七次涅槃	超越轮回，创世焰力。基础属性永久+230%	2.3	2.3	2.3	2.3	1.5	无敌模式(PVE)	2026-02-18 07:36:02.397441
\.


--
-- Data for Name: ascension_records; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.ascension_records (id, wallet, ascension_count, previous_level, bonuses, ascended_at) FROM stdin;
1	0xadb0ecf47e175089579da5182dd7707328575909	1	101	{"speed": 0.1, "attack": 0.1, "health": 0.1, "defense": 0.1, "cultivationSpeed": 0.1}	2026-02-18 07:46:59.05531
2	0xadb0ecf47e175089579da5182dd7707328575909	1	101	{"speed": 0.1, "attack": 0.1, "health": 0.1, "defense": 0.1, "cultivationSpeed": 0.1}	2026-02-18 07:47:15.628813
3	0xbot0000000000000000000000000000000000a1	1	100	{"speed": 0.1, "attack": 0.1, "health": 0.1, "defense": 0.1, "cultivationSpeed": 0.1}	2026-02-21 02:21:29.241907
\.


--
-- Data for Name: auction_bids; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.auction_bids (id, listing_id, bidder_wallet, bidder_name, bid_amount, created_at) FROM stdin;
1	1	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	100	2026-02-18 13:50:11.439722
2	6	0xbot0000000000000000000000000000000000b2	药仙·白露	1500	2026-02-21 01:51:15.512437
3	7	0xbot0000000000000000000000000000000000b2	药仙·白露	200	2026-02-21 06:13:16.479772
4	7	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名焰修	221	2026-02-21 07:28:19.96963
\.


--
-- Data for Name: auction_history; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.auction_history (id, listing_id, seller_wallet, buyer_wallet, item_name, item_type, item_quality, final_price, sold_at) FROM stdin;
1	1	0xadb0ecf47e175089579da5182dd7707328575909	0x82e402b05f3e936b63a874788c73e1552657c4f7	天罗手套·天	hands	rare	100	2026-02-19 12:39:20.538464
2	6	0xbot0000000000000000000000000000000000a1	0xbot0000000000000000000000000000000000b2	幽岚肩甲	shoulder	common	5000	2026-02-21 01:51:15.651429
3	7	0xbot0000000000000000000000000000000000a1	0x82e402b05f3e936b63a874788c73e1552657c4f7	幽冥焰杖	weapon	common	5000	2026-02-21 07:28:27.761583
\.


--
-- Data for Name: auction_listings; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.auction_listings (id, seller_wallet, seller_name, item_data, item_name, item_type, item_quality, starting_price, buyout_price, current_bid, current_bidder, bid_count, duration_hours, status, expires_at, created_at) FROM stdin;
6	0xbot0000000000000000000000000000000000a1	剑魔·青锋	{"id": 1771656525094.8723, "name": "幽岚肩甲", "slot": "shoulder", "type": "shoulder", "level": 15, "stats": {"health": 131, "defense": 24, "counterRate": 0.19}, "quality": "common", "category": "equipment", "equipType": "shoulder", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 15}	幽岚肩甲	shoulder	common	1000	5000	5000	0xbot0000000000000000000000000000000000b2	1	12	sold	2026-02-21 13:51:03.095	2026-02-21 01:51:03.096151
7	0xbot0000000000000000000000000000000000a1	无名修士	{"id": 1771671472237.8748, "name": "幽冥焰杖", "slot": "weapon", "type": "weapon", "level": 1, "stats": {"attack": 12, "critRate": 0.1, "critDamageBoost": 0.19}, "quality": "common", "category": "equipment", "equipType": "weapon", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 1}	幽冥焰杖	weapon	common	100	5000	5000	0x82e402b05f3e936b63a874788c73e1552657c4f7	2	12	sold	2026-02-21 18:01:18.442	2026-02-21 06:01:18.44325
1	0xadb0ecf47e175089579da5182dd7707328575909	无名修士	{"id": 1771357833356.723, "name": "天罗手套·天", "slot": "hands", "type": "hands", "level": 1, "stats": {"attack": 12, "critRate": 0, "comboRate": 0}, "quality": "rare", "equipType": "hands", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}	天罗手套·天	hands	rare	100	\N	100	0x82e402b05f3e936b63a874788c73e1552657c4f7	1	24	sold	2026-02-19 07:48:36.85	2026-02-18 07:48:36.851687
2	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	{"id": 1771440497366.911, "name": "星步鞋子·仙", "slot": "feet", "type": "feet", "level": 19, "stats": {"speed": 66, "defense": 36, "dodgeRate": 0}, "quality": "epic", "equipType": "feet", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 19}	星步鞋子·仙	feet	epic	99999	\N	0	\N	0	24	cancelled	2026-02-19 13:50:45.585	2026-02-18 13:50:45.586568
3	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	{"id": 1771440543442.0981, "name": "青命符文戒1·仙", "slot": "ring1", "type": "ring1", "level": 10, "stats": {"attack": 22, "critDamageBoost": 0.01, "finalDamageBoost": 0}, "quality": "epic", "equipType": "ring1", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 10}	青命符文戒1·仙	ring1	epic	100	\N	0	\N	0	24	cancelled	2026-02-20 22:07:48.245	2026-02-19 22:07:48.246647
4	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	{"id": 1771440543442.0981, "name": "青命符文戒1·仙", "slot": "ring1", "type": "ring1", "level": 10, "stats": {"attack": 22, "critDamageBoost": 0.01, "finalDamageBoost": 0}, "quality": "epic", "equipType": "ring1", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 10}	青命符文戒1·仙	ring1	epic	100	\N	0	\N	0	24	cancelled	2026-02-20 22:07:53.23	2026-02-19 22:07:53.230891
5	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	{"id": 1771440543442.0981, "name": "青命符文戒1·仙", "slot": "ring1", "type": "ring1", "level": 10, "stats": {"attack": 22, "critDamageBoost": 0.01, "finalDamageBoost": 0}, "quality": "epic", "equipType": "ring1", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 10}	青命符文戒1·仙	ring1	epic	50000	\N	0	\N	0	24	cancelled	2026-02-20 23:58:40.77	2026-02-19 23:58:40.771841
\.


--
-- Data for Name: boss_damage_log; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.boss_damage_log (id, boss_id, wallet, player_name, damage, attacks_count, last_attack_at) FROM stdin;
17	1	0xfad7eb0814b6838b05191a07fb987957d50c4ca9	无名修士	1	1	2026-02-19 12:51:17.836454-05
29	1	0xbot0000000000000000000000000000000000a1	剑魔·青锋	5	1	2026-02-21 01:54:50.214522-05
1	1	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	8847	30	2026-02-21 04:09:52.036032-05
\.


--
-- Data for Name: boss_rewards; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.boss_rewards (id, boss_id, wallet, rank, reward_stones, reward_items, claimed, created_at) FROM stdin;
\.


--
-- Data for Name: daily_dungeon_entries; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.daily_dungeon_entries (id, dungeon_id, wallet, player_name, result, rewards_earned, entry_date, created_at) FROM stdin;
1	1	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	defeat	{}	2026-02-18	2026-02-18 12:17:26.747137
2	1	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	victory	{"items": ["灵草"], "cultivation": 500, "spiritStones": 2000}	2026-02-20	2026-02-19 22:04:18.034614
3	2	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	victory	{"items": ["丹方碎片"], "cultivation": 2000, "spiritStones": 5000}	2026-02-20	2026-02-19 22:04:22.482303
4	3	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	victory	{"petEssence": 10, "cultivation": 5000, "spiritStones": 10000}	2026-02-20	2026-02-19 22:04:27.201705
5	4	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	victory	{"cultivation": 15000, "spiritStones": 30000, "refinementStones": 20}	2026-02-20	2026-02-19 22:04:35.299144
6	1	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	victory	{"items": ["灵草"], "cultivation": 500, "spiritStones": 2000}	2026-02-20	2026-02-20 00:00:19.503297
7	2	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	defeat	{}	2026-02-20	2026-02-20 00:00:22.36709
8	2	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	victory	{"items": ["丹方碎片"], "cultivation": 2000, "spiritStones": 5000}	2026-02-20	2026-02-20 00:00:25.953454
9	3	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	defeat	{}	2026-02-20	2026-02-20 00:00:29.766214
10	1	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	victory	{"items": ["灵草"], "cultivation": 500, "spiritStones": 2000}	2026-02-20	2026-02-20 00:00:40.766325
20	4	0xbot0000000000000000000000000000000000a1	剑魔·青锋	victory	{"cultivation": 15000, "spiritStones": 30000, "refinementStones": 20}	2026-02-21	2026-02-21 02:21:13.815489
21	1	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	victory	{"items": ["灵草"], "cultivation": 500, "spiritStones": 2000}	2026-02-21	2026-02-21 04:10:33.513142
22	1	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	defeat	{}	2026-02-21	2026-02-21 04:10:45.039744
23	1	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	victory	{"items": ["灵草"], "cultivation": 500, "spiritStones": 2000}	2026-02-21	2026-02-21 04:10:51.152786
24	1	0xbot0000000000000000000000000000000000a1	无名修士	defeat	{}	2026-02-21	2026-02-21 05:58:11.892105
25	1	0xbot0000000000000000000000000000000000a1	无名修士	defeat	{}	2026-02-21	2026-02-21 05:58:11.940301
26	1	0xbot0000000000000000000000000000000000a1	无名修士	defeat	{}	2026-02-21	2026-02-21 05:58:11.964761
27	1	0xbot0000000000000000000000000000000000c3	魔尊·血影	victory	{"items": ["灵草"], "cultivation": 500, "spiritStones": 2000}	2026-02-21	2026-02-21 05:58:12.023403
\.


--
-- Data for Name: daily_dungeons; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.daily_dungeons (id, name, description, difficulty, min_level, max_entries, enemy_config, rewards_config, created_at) FROM stdin;
1	焰草秘境	蕴含丰富焰草的秘境，击败守护兽可获得珍稀焰草	easy	1	3	{"hp": 5000, "name": "灵草守护兽", "level": 20, "attack": 200, "defense": 100}	{"items": ["灵草"], "cultivation": 500, "spiritStones": 2000}	2026-02-18 07:19:33.079678
2	丹火洞天	远古炼丹师留下的洞天，内有强大的火灵	normal	10	3	{"hp": 20000, "name": "火灵", "level": 50, "attack": 800, "defense": 400}	{"items": ["丹方碎片"], "cultivation": 2000, "spiritStones": 5000}	2026-02-18 07:19:33.079678
3	万兽山	凶兽横行的险地，击败兽王可获得焰兽精华	hard	30	2	{"hp": 80000, "name": "万兽之王", "level": 80, "attack": 3000, "defense": 1500}	{"petEssence": 10, "cultivation": 5000, "spiritStones": 10000}	2026-02-18 07:19:33.079678
4	焰魔战场	上古焰魔大战的遗迹，极其危险但奖励丰厚	hell	50	1	{"hp": 300000, "name": "残魂魔将", "level": 120, "attack": 10000, "defense": 5000}	{"cultivation": 15000, "spiritStones": 30000, "refinementStones": 20}	2026-02-18 07:19:33.079678
\.


--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.equipment (id, owner_id, name, type, slot, quality, level, required_realm, stats, is_equipped, equipped_slot, enhance_level, created_at) FROM stdin;
\.


--
-- Data for Name: event_claims; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_claims (id, event_id, wallet, claimed_at) FROM stdin;
1	6	0x82e402b05f3e936b63a874788c73e1552657c4f7	2026-02-21 04:17:39.859714-05
2	6	0xbot0000000000000000000000000000000000d4	2026-02-21 05:56:14.343734-05
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (id, name, type, config, starts_at, ends_at, active, created_at, description, rewards) FROM stdin;
6	开服庆典	login_bonus	{"dailyStones": 5000}	2026-02-21 04:17:15.214367	2026-03-23 04:17:15.214367	t	2026-02-21 04:17:15.214367	开服期间每日登录领取5000焰晶！	[{"type": "spiritStones", "amount": 5000}]
\.


--
-- Data for Name: friend_gifts; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.friend_gifts (id, from_wallet, to_wallet, gift_type, gift_value, message, claimed, created_at) FROM stdin;
1	0xbot0000000000000000000000000000000000a1	0x82e402b05f3e936b63a874788c73e1552657c4f7	spirit_stones	500		t	2026-02-21 01:50:17.488882
\.


--
-- Data for Name: friendships; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.friendships (id, from_wallet, to_wallet, status, created_at, updated_at) FROM stdin;
1	0xbot0000000000000000000000000000000000a1	0x82e402b05f3e936b63a874788c73e1552657c4f7	accepted	2026-02-20 23:34:08.028796	2026-02-20 23:34:08.028796
2	0xbot0000000000000000000000000000000000b2	0x82e402b05f3e936b63a874788c73e1552657c4f7	accepted	2026-02-20 23:34:08.028796	2026-02-20 23:34:08.028796
4	0xbot0000000000000000000000000000000000a1	0xbot0000000000000000000000000000000000c3	pending	2026-02-21 05:56:47.766867	2026-02-21 05:57:00.762578
\.


--
-- Data for Name: leaderboard_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leaderboard_cache (id, type, data, updated_at) FROM stdin;
1	level	[{"name": "无名修士", "rank": 1, "level": 1, "realm": "燃火期一层", "score": 1, "wallet": "0xf55dc98d490893d3e6be354bc01cdd7ca49e3eb9", "vip_level": 0, "combat_power": 225, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 2, "level": 1, "realm": "燃火期一层", "score": 1, "wallet": "0x207e30521e0903e2a0288ed162243dc740598c06", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 3, "level": 1, "realm": "燃火期一层", "score": 1, "wallet": "0xbf66c656b2aff9d39f2329e5b332f5e68600fe65", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 4, "level": 1, "realm": "燃火期一层", "score": 1, "wallet": "0x5b5717754beb158c384281cbec4c8a4682a1e4f8", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 5, "level": 1, "realm": "燃火期一层", "score": 1, "wallet": "0xfad7eb0814b6838b05191a07fb987957d50c4ca9", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 6, "level": 1, "realm": "燃火期一层", "score": 1, "wallet": "0xa40d60613f61e8546a9e3348b1f31630443485ba", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名焰修", "rank": 7, "level": 1, "realm": "燃火期一层", "score": 1, "wallet": "0x82e402b05f3e936b63a874788c73e1552657c4f7", "vip_level": 0, "combat_power": 225, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 8, "level": 1, "realm": "燃火期一层", "score": 1, "wallet": "0xadb0ecf47e175089579da5182dd7707328575909", "vip_level": 0, "combat_power": 225, "total_recharge": "2.00000000"}]	2026-02-21 07:27:15.593607
2	combat_power	[{"name": "无名修士", "rank": 1, "level": 1, "realm": "燃火期一层", "score": "225", "wallet": "0xf55dc98d490893d3e6be354bc01cdd7ca49e3eb9", "vip_level": 0, "combat_power": 225, "total_recharge": "0.00000000"}, {"name": "无名焰修", "rank": 2, "level": 1, "realm": "燃火期一层", "score": "225", "wallet": "0x82e402b05f3e936b63a874788c73e1552657c4f7", "vip_level": 0, "combat_power": 225, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 3, "level": 1, "realm": "燃火期一层", "score": "225", "wallet": "0xadb0ecf47e175089579da5182dd7707328575909", "vip_level": 0, "combat_power": 225, "total_recharge": "2.00000000"}, {"name": "无名修士", "rank": 4, "level": 1, "realm": "燃火期一层", "score": "0", "wallet": "0x5b5717754beb158c384281cbec4c8a4682a1e4f8", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 5, "level": 1, "realm": "燃火期一层", "score": "0", "wallet": "0xfad7eb0814b6838b05191a07fb987957d50c4ca9", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 6, "level": 1, "realm": "燃火期一层", "score": "0", "wallet": "0xa40d60613f61e8546a9e3348b1f31630443485ba", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 7, "level": 1, "realm": "燃火期一层", "score": "0", "wallet": "0x207e30521e0903e2a0288ed162243dc740598c06", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 8, "level": 1, "realm": "燃火期一层", "score": "0", "wallet": "0xbf66c656b2aff9d39f2329e5b332f5e68600fe65", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}]	2026-02-21 07:27:15.601939
5	recharge	[{"name": "无名修士", "rank": 1, "level": 1, "realm": "燃火期一层", "score": "2.00000000", "wallet": "0xadb0ecf47e175089579da5182dd7707328575909", "vip_level": 0, "combat_power": 225, "total_recharge": "2.00000000"}, {"name": "无名修士", "rank": 2, "level": 1, "realm": "燃火期一层", "score": "0.00000000", "wallet": "0x207e30521e0903e2a0288ed162243dc740598c06", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 3, "level": 1, "realm": "燃火期一层", "score": "0.00000000", "wallet": "0xbf66c656b2aff9d39f2329e5b332f5e68600fe65", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 4, "level": 1, "realm": "燃火期一层", "score": "0.00000000", "wallet": "0x5b5717754beb158c384281cbec4c8a4682a1e4f8", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 5, "level": 1, "realm": "燃火期一层", "score": "0.00000000", "wallet": "0xf55dc98d490893d3e6be354bc01cdd7ca49e3eb9", "vip_level": 0, "combat_power": 225, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 6, "level": 1, "realm": "燃火期一层", "score": "0.00000000", "wallet": "0xa40d60613f61e8546a9e3348b1f31630443485ba", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}, {"name": "无名焰修", "rank": 7, "level": 1, "realm": "燃火期一层", "score": "0.00000000", "wallet": "0x82e402b05f3e936b63a874788c73e1552657c4f7", "vip_level": 0, "combat_power": 225, "total_recharge": "0.00000000"}, {"name": "无名修士", "rank": 8, "level": 1, "realm": "燃火期一层", "score": "0.00000000", "wallet": "0xfad7eb0814b6838b05191a07fb987957d50c4ca9", "vip_level": 0, "combat_power": 0, "total_recharge": "0.00000000"}]	2026-02-21 07:27:15.60626
\.


--
-- Data for Name: monthly_cards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monthly_cards (id, wallet, purchased_at, expires_at, last_claim_date, days_claimed) FROM stdin;
\.


--
-- Data for Name: mounts; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.mounts (id, name, description, quality, emoji, attack_bonus, defense_bonus, health_bonus, speed_bonus, special_effect, obtain_method, created_at) FROM stdin;
1	白鹤	仙风道骨的白鹤，初学者的良伴	common	🦢	0.02	0.02	0.03	0.05	修炼速度+5%	新手赠送	2026-02-18 07:28:37.3665
2	赤焰马	浑身燃烧烈焰的骏马	rare	🐎	0.05	0.03	0.05	0.1	攻击附带火焰伤害	商城购买(10000灵石)	2026-02-18 07:28:37.3665
3	墨龙	远古墨龙后裔，威严霸气	epic	🐉	0.1	0.08	0.1	0.15	全属性+5%	世界Boss击杀奖励	2026-02-18 07:28:37.3665
4	九色鹿	传说中的瑞兽，带来好运	legendary	🦌	0.12	0.12	0.15	0.12	掉落率+20%	限时活动	2026-02-18 07:28:37.3665
5	鲲鹏	北冥有鱼，化而为鹏	mythic	🦅	0.2	0.15	0.2	0.25	全属性+15%，修炼速度+20%	飞升成仙	2026-02-18 07:28:37.3665
\.


--
-- Data for Name: pets; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.pets (id, owner_id, name, description, rarity, level, star, combat_attributes, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: pk_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pk_records (id, wallet_a, wallet_b, name_a, name_b, winner, winner_wallet, rounds_data, reward, created_at) FROM stdin;
\.


--
-- Data for Name: player_mail; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.player_mail (id, to_wallet, from_type, from_name, title, content, rewards, is_read, is_claimed, expires_at, created_at) FROM stdin;
1	0xf55dc98d490893d3e6be354bc01cdd7ca49e3eb9	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	f	f	\N	2026-02-21 07:18:33.768602-05
2	0x207e30521e0903e2a0288ed162243dc740598c06	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	f	f	\N	2026-02-21 07:18:33.773237-05
4	0xbf66c656b2aff9d39f2329e5b332f5e68600fe65	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	f	f	\N	2026-02-21 07:18:33.77687-05
5	0x5b5717754beb158c384281cbec4c8a4682a1e4f8	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	f	f	\N	2026-02-21 07:18:33.778517-05
6	0xbot0000000000000000000000000000000000d4	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	f	f	\N	2026-02-21 07:18:33.780127-05
7	0xbot0000000000000000000000000000000000e5	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	f	f	\N	2026-02-21 07:18:33.781979-05
8	0xfad7eb0814b6838b05191a07fb987957d50c4ca9	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	f	f	\N	2026-02-21 07:18:33.783449-05
9	0xa40d60613f61e8546a9e3348b1f31630443485ba	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	f	f	\N	2026-02-21 07:18:33.785328-05
10	0xbot0000000000000000000000000000000000b2	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	f	f	\N	2026-02-21 07:18:33.787209-05
11	0xbot0000000000000000000000000000000000c3	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	f	f	\N	2026-02-21 07:18:33.7887-05
12	0x82e402b05f3e936b63a874788c73e1552657c4f7	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	f	f	\N	2026-02-21 07:18:33.790104-05
13	0xadb0ecf47e175089579da5182dd7707328575909	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	f	f	\N	2026-02-21 07:18:33.791542-05
3	0xbot0000000000000000000000000000000000a1	admin	管理员	🔥 欢迎来到火之文明	感谢你加入焰修世界！这是一份新手礼物，祝你修炼顺利！	{"spiritStones": 5000, "reinforceStones": 10}	t	t	\N	2026-02-21 07:18:33.775281-05
\.


--
-- Data for Name: player_mounts; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.player_mounts (id, wallet, mount_id, level, exp, is_active, obtained_at) FROM stdin;
3	0xbot0000000000000000000000000000000000a1	1	1	0	f	2026-02-21 01:55:18.417926
4	0xbot0000000000000000000000000000000000a1	2	1	0	t	2026-02-21 01:55:18.449441
2	0x82e402b05f3e936b63a874788c73e1552657c4f7	1	1	0	f	2026-02-18 15:04:36.069215
1	0x82e402b05f3e936b63a874788c73e1552657c4f7	2	1	0	t	2026-02-18 15:04:33.864543
\.


--
-- Data for Name: player_titles; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.player_titles (id, wallet, title_id, is_active, obtained_at) FROM stdin;
6	0x207e30521e0903e2a0288ed162243dc740598c06	1	f	2026-02-19 12:39:20.745953
7	0xbf66c656b2aff9d39f2329e5b332f5e68600fe65	1	f	2026-02-19 12:40:29.869637
8	0xfad7eb0814b6838b05191a07fb987957d50c4ca9	1	f	2026-02-19 12:51:18.018764
9	0x5b5717754beb158c384281cbec4c8a4682a1e4f8	1	f	2026-02-19 13:05:26.286356
1	0x82e402b05f3e936b63a874788c73e1552657c4f7	1	f	2026-02-18 15:05:02.313083
2	0x82e402b05f3e936b63a874788c73e1552657c4f7	2	f	2026-02-18 15:05:02.315861
3	0x82e402b05f3e936b63a874788c73e1552657c4f7	3	f	2026-02-18 15:05:02.317055
4	0x82e402b05f3e936b63a874788c73e1552657c4f7	4	f	2026-02-18 15:05:02.318022
5	0x82e402b05f3e936b63a874788c73e1552657c4f7	8	t	2026-02-18 15:05:02.318852
10	0xbot0000000000000000000000000000000000a1	1	f	2026-02-21 01:55:36.103033
11	0xbot0000000000000000000000000000000000a1	8	f	2026-02-21 01:55:36.105216
12	0xbot0000000000000000000000000000000000a1	10	f	2026-02-21 01:55:36.106144
\.


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.players (id, wallet, name, game_data, vip_level, total_recharge, spirit_stones, level, realm, combat_power, first_recharge, daily_sign_date, daily_sign_streak, created_at, updated_at, banned) FROM stdin;
9	0xbot0000000000000000000000000000000000a1	剑魔·青锋	{"luck": 1, "name": "无名修士", "buffs": {"luckyCharm": 1771745064015}, "herbs": [{"id": "1771658626396e2zbml26r", "name": "玄阴草", "value": 45, "herbId": "dark_yin_grass", "quality": "uncommon", "obtainedAt": 1771658626396}, {"id": "17716586263966n4f9uhtr", "name": "灵精草", "value": 20, "herbId": "spirit_grass", "quality": "rare", "obtainedAt": 1771658626396}, {"id": "1771658626396iwxu42e2n", "name": "云雾花", "value": 15, "herbId": "cloud_flower", "quality": "common", "obtainedAt": 1771658626396}, {"id": "1771658626396ab2hzecgo", "name": "玄阴草", "value": 45, "herbId": "dark_yin_grass", "quality": "uncommon", "obtainedAt": 1771658626396}, {"id": "1771658626396zl59brtjb", "name": "玄阴草", "value": 30, "herbId": "dark_yin_grass", "quality": "common", "obtainedAt": 1771658626396}, {"id": "1771658626396cke9ekm2e", "name": "雷击根", "value": 50, "herbId": "thunder_root", "quality": "rare", "obtainedAt": 1771658626396}, {"id": "1771658626396ar1fia4n6", "name": "火心花", "value": 35, "herbId": "fire_heart_flower", "quality": "common", "obtainedAt": 1771658626396}, {"id": "1771658626396fn5n2wy9r", "name": "云雾花", "value": 15, "herbId": "cloud_flower", "quality": "common", "obtainedAt": 1771658626396}, {"id": "1771658626396pv4y85ka7", "name": "云雾花", "value": 15, "herbId": "cloud_flower", "quality": "common", "obtainedAt": 1771658626396}, {"id": "1771658626396x28ickbjp", "name": "雷击根", "value": 25, "herbId": "thunder_root", "quality": "common", "obtainedAt": 1771658626397}, {"id": "17716586263970s6k4juch", "name": "雷击根", "value": 50, "herbId": "thunder_root", "quality": "rare", "obtainedAt": 1771658626397}, {"id": "1771658626397o3z2hmm0j", "name": "雷击根", "value": 37, "herbId": "thunder_root", "quality": "uncommon", "obtainedAt": 1771658626397}, {"id": "177165862639770lwg9hz2", "name": "雷击根", "value": 25, "herbId": "thunder_root", "quality": "common", "obtainedAt": 1771658626397}, {"id": "1771658626397ogk9a4mu3", "name": "云雾花", "value": 15, "herbId": "cloud_flower", "quality": "common", "obtainedAt": 1771658626397}, {"id": "1771658626397f9xk2xnag", "name": "火心花", "value": 105, "herbId": "fire_heart_flower", "quality": "epic", "obtainedAt": 1771658626397}, {"id": "17716586263970kj7uxswf", "name": "雷击根", "value": 25, "herbId": "thunder_root", "quality": "common", "obtainedAt": 1771658626397}, {"id": "1771658626397v88647c0x", "name": "云雾花", "value": 22, "herbId": "cloud_flower", "quality": "uncommon", "obtainedAt": 1771658626397}, {"id": "1771658626397b7y17kcpq", "name": "火心花", "value": 35, "herbId": "fire_heart_flower", "quality": "common", "obtainedAt": 1771658626397}, {"id": "fire_heart_flower", "name": "火心花", "value": 35, "herbId": "fire_heart_flower", "herb_id": "fire_heart_flower", "quality": "common", "obtainedAt": 1771658685041}, {"id": "1771662181838b9ubxexh5", "name": "灵精草", "value": 10, "herbId": "spirit_grass", "quality": "common", "obtainedAt": 1771662181838}, {"id": "1771662181838hp8woc5ht", "name": "云雾花", "value": 22, "herbId": "cloud_flower", "quality": "uncommon", "obtainedAt": 1771662181838}, {"id": "1771662181838owk101mvl", "name": "玄阴草", "value": 30, "herbId": "dark_yin_grass", "quality": "common", "obtainedAt": 1771662181838}, {"id": "1771662181838g5zy1vaxz", "name": "火心花", "value": 35, "herbId": "fire_heart_flower", "quality": "common", "obtainedAt": 1771662181838}, {"id": "1771662181838s8zrkajm5", "name": "雷击根", "value": 25, "herbId": "thunder_root", "quality": "common", "obtainedAt": 1771662181838}, {"id": "1771662181838c0vm1oxwr", "name": "灵精草", "value": 10, "herbId": "spirit_grass", "quality": "common", "obtainedAt": 1771662181838}, {"id": "1771662181838exbnltl54", "name": "玄阴草", "value": 30, "herbId": "dark_yin_grass", "quality": "common", "obtainedAt": 1771662181838}, {"id": "1771662181838z3v2za7xq", "name": "云雾花", "value": 15, "herbId": "cloud_flower", "quality": "common", "obtainedAt": 1771662181838}, {"id": "1771662181838nopx5q1zu", "name": "云雾花", "value": 15, "herbId": "cloud_flower", "quality": "common", "obtainedAt": 1771662181838}, {"id": "1771662181838fjilixf5a", "name": "玄阴草", "value": 45, "herbId": "dark_yin_grass", "quality": "uncommon", "obtainedAt": 1771662181838}, {"id": "1771662181838zy3o5bl7t", "name": "雷击根", "value": 25, "herbId": "thunder_root", "quality": "common", "obtainedAt": 1771662181838}, {"id": "1771662181838l1iaouv5q", "name": "灵精草", "value": 10, "herbId": "spirit_grass", "quality": "common", "obtainedAt": 1771662181838}, {"id": "1771662181838ku312hua5", "name": "灵精草", "value": 20, "herbId": "spirit_grass", "quality": "rare", "obtainedAt": 1771662181838}, {"id": "17716621818383xjkswend", "name": "灵精草", "value": 15, "herbId": "spirit_grass", "quality": "uncommon", "obtainedAt": 1771662181838}, {"id": "17716621818389f26vzw3y", "name": "云雾花", "value": 22, "herbId": "cloud_flower", "quality": "uncommon", "obtainedAt": 1771662181838}, {"id": "1771662181838r5i9hm8xk", "name": "云雾花", "value": 22, "herbId": "cloud_flower", "quality": "uncommon", "obtainedAt": 1771662181838}], "items": [{"id": 1771671308815.9092, "name": "火鼠", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 9, "strength": 8, "constitution": 10, "intelligence": 1}, "experience": 0, "description": "活泼的啮齿类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 7, "attack": 14, "health": 114, "defense": 6, "critRate": 0.08, "stunRate": 0.05, "comboRate": 0.1, "dodgeRate": 0.07, "healBoost": 0.06, "critResist": 0.09, "stunResist": 0.07, "combatBoost": 0.09, "comboResist": 0.07, "counterRate": 0.1, "dodgeResist": 0.07, "vampireRate": 0.05, "counterResist": 0.08, "vampireResist": 0.09, "critDamageBoost": 0.09, "resistanceBoost": 0.1, "critDamageReduce": 0.08, "finalDamageBoost": 0.07, "finalDamageReduce": 0.07}}], "level": 50, "pills": [], "realm": "化焰五重", "spirit": 148269.79999999993, "herbRate": 1, "isGMMode": false, "activePet": null, "artifacts": [], "gachaPity": {"petCount": 2, "equipCount": 2}, "petConfig": {"rarityMap": {"divine": {"name": "神品", "color": "#FF0000", "probability": 0.02, "essenceBonus": 50}, "mortal": {"name": "凡品", "color": "#32CD32", "probability": 0.5, "essenceBonus": 5}, "mystic": {"name": "玄品", "color": "#9932CC", "probability": 0.15, "essenceBonus": 20}, "celestial": {"name": "仙品", "color": "#FFD700", "probability": 0.08, "essenceBonus": 30}, "spiritual": {"name": "灵品", "color": "#1E90FF", "probability": 0.25, "essenceBonus": 10}}}, "isDarkMode": false, "itemsFound": 0, "petEssence": 1135, "spiritRate": 3.9000000000000004, "alchemyRate": 1, "cultivation": 0, "isNewPlayer": true, "pillRecipes": ["spirit_gathering"], "pillsCrafted": 0, "spiritStones": 5004715, "activeEffects": [], "pillFragments": {}, "pillsConsumed": 0, "storageExpand": {"equip": 1}, "baseAttributes": {"speed": 500, "attack": 8000, "health": 50000, "defense": 3000}, "eventTriggered": 0, "lastOnlineTime": 1771670931996, "maxCultivation": 100, "unlockedRealms": ["练气一层"], "unlockedSkills": [], "artifactBonuses": {"speed": 0, "attack": 0, "health": 0, "defense": 0, "critRate": 0, "stunRate": 0, "comboRate": 0, "dodgeRate": 0, "healBoost": 0, "critResist": 0, "spiritRate": 1, "stunResist": 0, "combatBoost": 0, "comboResist": 0, "counterRate": 0, "dodgeResist": 0, "vampireRate": 0, "counterResist": 0, "vampireResist": 0, "critDamageBoost": 0, "cultivationRate": 1, "resistanceBoost": 0, "critDamageReduce": 0, "finalDamageBoost": 0, "finalDamageReduce": 0}, "cultivationRate": 1, "nameChangeCount": 0, "reinforceStones": 503, "wishlistEnabled": false, "activeMountBonus": {"speed_bonus": 0.1, "attack_bonus": 0.05, "health_bonus": 0.05, "defense_bonus": 0.03}, "activeTitleBonus": {"speed_bonus": 0, "attack_bonus": 0, "health_bonus": 0, "defense_bonus": 0}, "combatAttributes": {"critRate": 0, "stunRate": 0, "comboRate": 0, "dodgeRate": 0, "counterRate": 0, "vampireRate": 0}, "combatResistance": {"critResist": 0, "stunResist": 0, "comboResist": 0, "dodgeResist": 0, "counterResist": 0, "vampireResist": 0}, "dungeonBossKills": 1, "dungeonTotalRuns": 0, "explorationCount": 0, "refinementStones": 196, "autoSellQualities": [], "breakthroughCount": 0, "dungeonDeathCount": 0, "dungeonDifficulty": 1, "dungeonEliteKills": 2, "dungeonTotalKills": 5, "equippedArtifacts": {"belt": null, "body": null, "feet": null, "head": null, "legs": null, "hands": null, "ring1": null, "ring2": null, "wrist": null, "weapon": null, "artifact": null, "necklace": null, "shoulder": null}, "specialAttributes": {"healBoost": 0, "combatBoost": 0, "critDamageBoost": 0, "resistanceBoost": 0, "critDamageReduce": 0, "finalDamageBoost": 0, "finalDamageReduce": 0}, "unlockedLocations": ["新手村"], "autoReleaseRarities": [], "dungeonHighestFloor": 10, "dungeonTotalRewards": 670, "unlockedPillRecipes": 0, "totalCultivationTime": 35, "completedAchievements": ["cultivation_1", "resources_1", "resources_2", "resources_3", "resources_4", "resources_5", "resources_6", "resources_7", "resources_8"], "dungeonHighestFloor_2": 0, "dungeonHighestFloor_5": 5, "selectedWishPetRarity": null, "dungeonHighestFloor_10": 0, "dungeonLastFailedFloor": 0, "dungeonHighestFloor_100": 0, "selectedWishEquipQuality": null}	0	0.00000000	5004715	50	化焰五重	999999	f	\N	0	2026-02-20 23:34:08.010864	2026-02-21 05:49:28.336774	f
4	0xf55dc98d490893d3e6be354bc01cdd7ca49e3eb9	无名修士	{"luck": 1, "name": "无名修士", "herbs": [], "items": [], "level": 1, "pills": [], "realm": "燃火期一层", "spirit": 95, "herbRate": 1, "isGMMode": false, "activePet": null, "artifacts": [], "petConfig": {"rarityMap": {"divine": {"name": "神品", "color": "#FF0000", "probability": 0.02, "essenceBonus": 50}, "mortal": {"name": "凡品", "color": "#32CD32", "probability": 0.5, "essenceBonus": 5}, "mystic": {"name": "玄品", "color": "#9932CC", "probability": 0.15, "essenceBonus": 20}, "celestial": {"name": "仙品", "color": "#FFD700", "probability": 0.08, "essenceBonus": 30}, "spiritual": {"name": "灵品", "color": "#1E90FF", "probability": 0.25, "essenceBonus": 10}}}, "isDarkMode": true, "itemsFound": 0, "petEssence": 0, "spiritRate": 1, "alchemyRate": 1, "cultivation": 0, "isNewPlayer": true, "pillRecipes": [], "pillsCrafted": 0, "spiritStones": 100000, "activeEffects": [], "pillFragments": {}, "pillsConsumed": 0, "baseAttributes": {"speed": 10, "attack": 10, "health": 100, "defense": 5}, "eventTriggered": 0, "lastOnlineTime": 1771439259224, "maxCultivation": 100, "unlockedRealms": ["燃火期一层"], "unlockedSkills": [], "artifactBonuses": {"speed": 0, "attack": 0, "health": 0, "defense": 0, "critRate": 0, "stunRate": 0, "comboRate": 0, "dodgeRate": 0, "healBoost": 0, "critResist": 0, "spiritRate": 1, "stunResist": 0, "combatBoost": 0, "comboResist": 0, "counterRate": 0, "dodgeResist": 0, "vampireRate": 0, "counterResist": 0, "vampireResist": 0, "critDamageBoost": 0, "cultivationRate": 1, "resistanceBoost": 0, "critDamageReduce": 0, "finalDamageBoost": 0, "finalDamageReduce": 0}, "cultivationRate": 1, "nameChangeCount": 0, "reinforceStones": 0, "wishlistEnabled": false, "combatAttributes": {"critRate": 0, "stunRate": 0, "comboRate": 0, "dodgeRate": 0, "counterRate": 0, "vampireRate": 0}, "combatResistance": {"critResist": 0, "stunResist": 0, "comboResist": 0, "dodgeResist": 0, "counterResist": 0, "vampireResist": 0}, "dungeonBossKills": 0, "dungeonTotalRuns": 0, "explorationCount": 0, "refinementStones": 0, "autoSellQualities": [], "breakthroughCount": 0, "dungeonDeathCount": 0, "dungeonDifficulty": 1, "dungeonEliteKills": 0, "dungeonTotalKills": 0, "equippedArtifacts": {"belt": null, "body": null, "feet": null, "head": null, "legs": null, "hands": null, "ring1": null, "ring2": null, "wrist": null, "weapon": null, "artifact": null, "necklace": null, "shoulder": null}, "specialAttributes": {"healBoost": 0, "combatBoost": 0, "critDamageBoost": 0, "resistanceBoost": 0, "critDamageReduce": 0, "finalDamageBoost": 0, "finalDamageReduce": 0}, "unlockedLocations": ["薪火村"], "autoReleaseRarities": [], "dungeonHighestFloor": 0, "dungeonTotalRewards": 0, "unlockedPillRecipes": 0, "totalCultivationTime": 95, "completedAchievements": [], "dungeonHighestFloor_2": 0, "dungeonHighestFloor_5": 0, "selectedWishPetRarity": null, "dungeonHighestFloor_10": 0, "dungeonLastFailedFloor": 0, "dungeonHighestFloor_100": 0, "selectedWishEquipQuality": null}	0	0.00000000	100000	1	燃火期一层	225	f	\N	0	2026-02-18 13:24:30.774155	2026-02-18 13:27:39.357996	f
6	0x207e30521e0903e2a0288ed162243dc740598c06	无名修士	{"name": "TestPlayer", "level": 1, "realm": "练气期", "spiritStones": 100000}	0	0.00000000	100500	1	燃火期一层	0	f	2026-02-19	1	2026-02-19 12:39:18.746658	2026-02-19 12:39:18.821874	f
7	0xbf66c656b2aff9d39f2329e5b332f5e68600fe65	无名修士	{"name": "TestPlayer", "level": 1, "realm": "练气期", "spiritStones": 100000}	0	0.00000000	100500	1	燃火期一层	0	f	2026-02-19	1	2026-02-19 12:40:27.803176	2026-02-19 12:40:27.894942	f
8	0x5b5717754beb158c384281cbec4c8a4682a1e4f8	无名修士	{"name": "TestPlayer", "level": 1, "realm": "练气期", "spiritStones": 100500}	0	0.00000000	100500	1	燃火期一层	0	f	2026-02-19	1	2026-02-19 13:05:24.336309	2026-02-19 13:05:24.426398	f
12	0xbot0000000000000000000000000000000000d4	小焰·新手	{"name": "鬼修·幽冥", "items": [{"id": 1771671442491.5056, "name": "混沌焰杖·圣", "slot": "weapon", "type": "weapon", "level": 14, "stats": {"attack": 77, "critRate": 0.41, "critDamageBoost": 0.9}, "quality": "legendary", "equipType": "weapon", "qualityInfo": {"name": "极品", "color": "#ff9800", "statMod": 2.5, "maxStatMod": 3.5}, "requiredRealm": 14}, {"id": 1771671516229.6143, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 6, "strength": 9, "constitution": 10, "intelligence": 5}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 7, "attack": 14, "health": 113, "defense": 6, "critRate": 0.09, "stunRate": 0.07, "comboRate": 0.09, "dodgeRate": 0.09, "healBoost": 0.05, "critResist": 0.06, "stunResist": 0.07, "combatBoost": 0.08, "comboResist": 0.06, "counterRate": 0.08, "dodgeResist": 0.09, "vampireRate": 0.09, "counterResist": 0.1, "vampireResist": 0.06, "critDamageBoost": 0.09, "resistanceBoost": 0.09, "critDamageReduce": 0.06, "finalDamageBoost": 0.07, "finalDamageReduce": 0.06}}], "level": 10, "realm": "燃火期十层", "spirit": 500, "gachaPity": {"petCount": 1, "equipCount": 1}, "petEssence": 5, "realmIndex": 13, "cultivation": 45000, "spiritStones": 374900, "baseAttributes": {"speed": 80, "attack": 500, "health": 3000, "defense": 200}, "reinforceStones": 0, "shopWeeklyPurchases": {"legendary": {"count": 1, "weekStart": 1771218000000}}}	0	0.00000000	374900	10	燃火期十层	10000	f	2026-02-21	1	2026-02-20 23:40:20.125482	2026-02-21 05:55:11.855344	f
13	0xbot0000000000000000000000000000000000e5	焰灵·初修	{"name": "妖修·九尾", "items": [{"id": 1771671464433.3562, "name": "云甲肩甲·道", "slot": "shoulder", "type": "shoulder", "level": 3, "stats": {"health": 121, "defense": 13, "counterRate": 0.09}, "quality": "uncommon", "category": "equipment", "equipType": "shoulder", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 3}, {"id": 1771671531638.7888, "name": "灵猫", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 5, "strength": 6, "constitution": 2, "intelligence": 6}, "experience": 0, "description": "敏捷的小型焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 8, "attack": 11, "health": 103, "defense": 8, "critRate": 0.07, "stunRate": 0.09, "comboRate": 0.08, "dodgeRate": 0.06, "healBoost": 0.08, "critResist": 0.08, "stunResist": 0.08, "combatBoost": 0.08, "comboResist": 0.06, "counterRate": 0.07, "dodgeResist": 0.09, "vampireRate": 0.08, "counterResist": 0.05, "vampireResist": 0.05, "critDamageBoost": 0.08, "resistanceBoost": 0.09, "critDamageReduce": 0.05, "finalDamageBoost": 0.06, "finalDamageReduce": 0.06}}, {"id": 1771671531719.224, "name": "天行鞋子·仙", "slot": "feet", "type": "feet", "level": 12, "stats": {"speed": 51, "defense": 19, "dodgeRate": 0.25}, "quality": "epic", "category": "equipment", "equipType": "feet", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 12}, {"id": 1771671531805.5637, "name": "草兔", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 2, "strength": 6, "constitution": 7, "intelligence": 9}, "experience": 0, "description": "温顺的兔类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 9, "attack": 11, "health": 104, "defense": 7, "critRate": 0.07, "stunRate": 0.07, "comboRate": 0.1, "dodgeRate": 0.06, "healBoost": 0.09, "critResist": 0.08, "stunResist": 0.06, "combatBoost": 0.08, "comboResist": 0.06, "counterRate": 0.08, "dodgeResist": 0.09, "vampireRate": 0.06, "counterResist": 0.06, "vampireResist": 0.09, "critDamageBoost": 0.06, "resistanceBoost": 0.07, "critDamageReduce": 0.07, "finalDamageBoost": 0.08, "finalDamageReduce": 0.08}}, {"id": 1771671531894.8552, "name": "火凤凰", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 1, "strength": 6, "constitution": 7, "intelligence": 3}, "experience": 0, "description": "浴火重生的永恒之鸟", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 26, "attack": 32, "health": 348, "defense": 24, "critRate": 0.08, "stunRate": 0.15, "comboRate": 0.16, "dodgeRate": 0.13, "healBoost": 0.1, "critResist": 0.13, "stunResist": 0.14, "combatBoost": 0.08, "comboResist": 0.15, "counterRate": 0.13, "dodgeResist": 0.14, "vampireRate": 0.14, "counterResist": 0.12, "vampireResist": 0.09, "critDamageBoost": 0.15, "resistanceBoost": 0.1, "critDamageReduce": 0.14, "finalDamageBoost": 0.11, "finalDamageReduce": 0.11}}, {"id": 1771671531976.277, "name": "风隼", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 2, "strength": 5, "constitution": 9, "intelligence": 3}, "experience": 0, "description": "速度极快的飞行焰兽", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 18, "attack": 28, "health": 237, "defense": 15, "critRate": 0.09, "stunRate": 0.07, "comboRate": 0.11, "dodgeRate": 0.08, "healBoost": 0.12, "critResist": 0.13, "stunResist": 0.13, "combatBoost": 0.11, "comboResist": 0.07, "counterRate": 0.09, "dodgeResist": 0.08, "vampireRate": 0.13, "counterResist": 0.07, "vampireResist": 0.13, "critDamageBoost": 0.09, "resistanceBoost": 0.1, "critDamageReduce": 0.13, "finalDamageBoost": 0.13, "finalDamageReduce": 0.12}}, {"id": 1771671542604.0227, "name": "玄系腰带", "slot": "belt", "type": "belt", "level": 10, "stats": {"health": 89, "defense": 12, "combatBoost": 0.19}, "quality": "common", "category": "equipment", "equipType": "belt", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 10}, {"id": 1771671550166.5647, "name": "赤铜护腕", "slot": "wrist", "type": "wrist", "level": 3, "stats": {"defense": 5, "counterRate": 0.09, "vampireRate": 0.09}, "quality": "common", "category": "equipment", "equipType": "wrist", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 3}, {"id": 1771671550219.6743, "name": "混元衣服", "slot": "body", "type": "body", "level": 4, "stats": {"health": 145, "defense": 20, "finalDamageReduce": 0.08}, "quality": "common", "category": "equipment", "equipType": "body", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 4}, {"id": 1771671550219.7185, "name": "幽系腰带·道", "slot": "belt", "type": "belt", "level": 9, "stats": {"health": 176, "defense": 18, "combatBoost": 0.17}, "quality": "uncommon", "category": "equipment", "equipType": "belt", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 9}, {"id": 1771671550219.3088, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 10, "strength": 9, "constitution": 8, "intelligence": 5}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 8, "attack": 15, "health": 105, "defense": 7, "critRate": 0.09, "stunRate": 0.09, "comboRate": 0.07, "dodgeRate": 0.06, "healBoost": 0.05, "critResist": 0.1, "stunResist": 0.06, "combatBoost": 0.08, "comboResist": 0.06, "counterRate": 0.06, "dodgeResist": 0.09, "vampireRate": 0.05, "counterResist": 0.1, "vampireResist": 0.06, "critDamageBoost": 0.06, "resistanceBoost": 0.07, "critDamageReduce": 0.08, "finalDamageBoost": 0.08, "finalDamageReduce": 0.07}}, {"id": 1771671550219.8062, "name": "风隼", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 5, "strength": 7, "constitution": 9, "intelligence": 3}, "experience": 0, "description": "速度极快的飞行焰兽", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 16, "attack": 30, "health": 231, "defense": 14, "critRate": 0.14, "stunRate": 0.07, "comboRate": 0.08, "dodgeRate": 0.08, "healBoost": 0.1, "critResist": 0.09, "stunResist": 0.1, "combatBoost": 0.09, "comboResist": 0.13, "counterRate": 0.12, "dodgeResist": 0.1, "vampireRate": 0.13, "counterResist": 0.09, "vampireResist": 0.11, "critDamageBoost": 0.11, "resistanceBoost": 0.12, "critDamageReduce": 0.08, "finalDamageBoost": 0.14, "finalDamageReduce": 0.07}}, {"id": 1771671550219.0278, "name": "紫晶手套·道", "slot": "hands", "type": "hands", "level": 13, "stats": {"attack": 22, "critRate": 0.08, "comboRate": 0.23}, "quality": "uncommon", "category": "equipment", "equipType": "hands", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 13}, {"id": 1771671550219.9656, "name": "云豹", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 3, "strength": 6, "constitution": 4, "intelligence": 8}, "experience": 0, "description": "敏捷的猎手", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 16, "attack": 26, "health": 208, "defense": 15, "critRate": 0.07, "stunRate": 0.13, "comboRate": 0.1, "dodgeRate": 0.13, "healBoost": 0.12, "critResist": 0.09, "stunResist": 0.14, "combatBoost": 0.13, "comboResist": 0.12, "counterRate": 0.11, "dodgeResist": 0.08, "vampireRate": 0.11, "counterResist": 0.13, "vampireResist": 0.1, "critDamageBoost": 0.14, "resistanceBoost": 0.1, "critDamageReduce": 0.12, "finalDamageBoost": 0.12, "finalDamageReduce": 0.08}}, {"id": 1771671550219.7996, "name": "天护肩甲·道", "slot": "shoulder", "type": "shoulder", "level": 6, "stats": {"health": 135, "defense": 12, "counterRate": 0.11}, "quality": "uncommon", "category": "equipment", "equipType": "shoulder", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 6}, {"id": 1771671550219.5544, "name": "幽岚肩甲·道", "slot": "shoulder", "type": "shoulder", "level": 7, "stats": {"health": 88, "defense": 14, "counterRate": 0.14}, "quality": "uncommon", "category": "equipment", "equipType": "shoulder", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 7}, {"id": 1771671550219.0532, "name": "冰狼", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 8, "strength": 10, "constitution": 7, "intelligence": 9}, "experience": 0, "description": "冰原霸主", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 26, "attack": 31, "health": 323, "defense": 22, "critRate": 0.09, "stunRate": 0.1, "comboRate": 0.1, "dodgeRate": 0.16, "healBoost": 0.12, "critResist": 0.09, "stunResist": 0.09, "combatBoost": 0.11, "comboResist": 0.14, "counterRate": 0.16, "dodgeResist": 0.11, "vampireRate": 0.11, "counterResist": 0.13, "vampireResist": 0.08, "critDamageBoost": 0.14, "resistanceBoost": 0.1, "critDamageReduce": 0.14, "finalDamageBoost": 0.14, "finalDamageReduce": 0.11}}, {"id": 1771671550219.9016, "name": "冰狼", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 6, "strength": 9, "constitution": 1, "intelligence": 6}, "experience": 0, "description": "冰原霸主", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 18, "attack": 38, "health": 307, "defense": 17, "critRate": 0.13, "stunRate": 0.16, "comboRate": 0.13, "dodgeRate": 0.11, "healBoost": 0.13, "critResist": 0.08, "stunResist": 0.1, "combatBoost": 0.1, "comboResist": 0.15, "counterRate": 0.15, "dodgeResist": 0.13, "vampireRate": 0.12, "counterResist": 0.14, "vampireResist": 0.14, "critDamageBoost": 0.11, "resistanceBoost": 0.15, "critDamageReduce": 0.09, "finalDamageBoost": 0.11, "finalDamageReduce": 0.14}}, {"id": 1771671550248.2969, "name": "玄龟", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 2, "strength": 3, "constitution": 5, "intelligence": 2}, "experience": 0, "description": "擅长防御的水系焰兽", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 17, "attack": 25, "health": 217, "defense": 14, "critRate": 0.12, "stunRate": 0.1, "comboRate": 0.09, "dodgeRate": 0.13, "healBoost": 0.11, "critResist": 0.08, "stunResist": 0.12, "combatBoost": 0.11, "comboResist": 0.09, "counterRate": 0.09, "dodgeResist": 0.12, "vampireRate": 0.11, "counterResist": 0.11, "vampireResist": 0.11, "critDamageBoost": 0.13, "resistanceBoost": 0.1, "critDamageReduce": 0.12, "finalDamageBoost": 0.1, "finalDamageReduce": 0.1}}, {"id": 1771671550387.261, "name": "混沌焰杖·道", "slot": "weapon", "type": "weapon", "level": 12, "stats": {"attack": 44, "critRate": 0.24, "critDamageBoost": 0.48}, "quality": "uncommon", "category": "equipment", "equipType": "weapon", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 12}, {"id": 1771671550387.0337, "name": "岩龟", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 7, "strength": 4, "constitution": 6, "intelligence": 9}, "experience": 0, "description": "坚不可摧的守护者", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 18, "attack": 33, "health": 315, "defense": 21, "critRate": 0.13, "stunRate": 0.14, "comboRate": 0.15, "dodgeRate": 0.09, "healBoost": 0.08, "critResist": 0.1, "stunResist": 0.11, "combatBoost": 0.08, "comboResist": 0.12, "counterRate": 0.13, "dodgeResist": 0.1, "vampireRate": 0.11, "counterResist": 0.15, "vampireResist": 0.16, "critDamageBoost": 0.13, "resistanceBoost": 0.13, "critDamageReduce": 0.13, "finalDamageBoost": 0.09, "finalDamageReduce": 0.11}}, {"id": 1771671550387.9053, "name": "火鼠", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 10, "strength": 4, "constitution": 10, "intelligence": 2}, "experience": 0, "description": "活泼的啮齿类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 7, "attack": 12, "health": 115, "defense": 6, "critRate": 0.08, "stunRate": 0.09, "comboRate": 0.08, "dodgeRate": 0.09, "healBoost": 0.05, "critResist": 0.09, "stunResist": 0.05, "combatBoost": 0.1, "comboResist": 0.09, "counterRate": 0.07, "dodgeResist": 0.1, "vampireRate": 0.09, "counterResist": 0.09, "vampireResist": 0.09, "critDamageBoost": 0.09, "resistanceBoost": 0.1, "critDamageReduce": 0.07, "finalDamageBoost": 0.07, "finalDamageReduce": 0.1}}, {"id": 1771671550387.261, "name": "灵猫", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 5, "strength": 8, "constitution": 3, "intelligence": 4}, "experience": 0, "description": "敏捷的小型焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 6, "attack": 12, "health": 105, "defense": 6, "critRate": 0.08, "stunRate": 0.06, "comboRate": 0.07, "dodgeRate": 0.06, "healBoost": 0.06, "critResist": 0.1, "stunResist": 0.07, "combatBoost": 0.09, "comboResist": 0.07, "counterRate": 0.07, "dodgeResist": 0.06, "vampireRate": 0.05, "counterResist": 0.07, "vampireResist": 0.07, "critDamageBoost": 0.09, "resistanceBoost": 0.09, "critDamageReduce": 0.05, "finalDamageBoost": 0.07, "finalDamageReduce": 0.08}}, {"id": 1771671550387.1687, "name": "玄龟", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 9, "strength": 10, "constitution": 10, "intelligence": 4}, "experience": 0, "description": "擅长防御的水系焰兽", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 18, "attack": 27, "health": 239, "defense": 14, "critRate": 0.13, "stunRate": 0.11, "comboRate": 0.09, "dodgeRate": 0.11, "healBoost": 0.12, "critResist": 0.13, "stunResist": 0.08, "combatBoost": 0.08, "comboResist": 0.08, "counterRate": 0.12, "dodgeResist": 0.08, "vampireRate": 0.11, "counterResist": 0.1, "vampireResist": 0.14, "critDamageBoost": 0.12, "resistanceBoost": 0.13, "critDamageReduce": 0.1, "finalDamageBoost": 0.12, "finalDamageReduce": 0.08}}, {"id": 1771671550387.607, "name": "九天焰杖·仙", "slot": "weapon", "type": "weapon", "level": 5, "stats": {"attack": 33, "critRate": 0.16, "critDamageBoost": 0.34}, "quality": "epic", "category": "equipment", "equipType": "weapon", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 5}, {"id": 1771671550387.85, "name": "草兔", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 7, "strength": 8, "constitution": 10, "intelligence": 3}, "experience": 0, "description": "温顺的兔类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 6, "attack": 12, "health": 108, "defense": 7, "critRate": 0.07, "stunRate": 0.07, "comboRate": 0.08, "dodgeRate": 0.06, "healBoost": 0.07, "critResist": 0.07, "stunResist": 0.09, "combatBoost": 0.05, "comboResist": 0.07, "counterRate": 0.05, "dodgeResist": 0.05, "vampireRate": 0.07, "counterResist": 0.07, "vampireResist": 0.07, "critDamageBoost": 0.06, "resistanceBoost": 0.08, "critDamageReduce": 0.06, "finalDamageBoost": 0.07, "finalDamageReduce": 0.06}}, {"id": 1771671550387.9182, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 6, "strength": 9, "constitution": 9, "intelligence": 1}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 8, "attack": 15, "health": 110, "defense": 5, "critRate": 0.06, "stunRate": 0.07, "comboRate": 0.09, "dodgeRate": 0.08, "healBoost": 0.07, "critResist": 0.09, "stunResist": 0.09, "combatBoost": 0.06, "comboResist": 0.06, "counterRate": 0.09, "dodgeResist": 0.09, "vampireRate": 0.08, "counterResist": 0.07, "vampireResist": 0.07, "critDamageBoost": 0.05, "resistanceBoost": 0.05, "critDamageReduce": 0.08, "finalDamageBoost": 0.08, "finalDamageReduce": 0.09}}, {"id": 1771671550387.8403, "name": "幽宝焰器", "slot": "artifact", "type": "artifact", "level": 11, "stats": {"attack": 0, "critRate": 0.38, "comboRate": 0.34}, "quality": "common", "category": "equipment", "equipType": "artifact", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 11}, {"id": 1771671550387.3625, "name": "火凤凰", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 9, "strength": 4, "constitution": 6, "intelligence": 7}, "experience": 0, "description": "浴火重生的永恒之鸟", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 24, "attack": 43, "health": 314, "defense": 19, "critRate": 0.15, "stunRate": 0.14, "comboRate": 0.14, "dodgeRate": 0.13, "healBoost": 0.1, "critResist": 0.16, "stunResist": 0.15, "combatBoost": 0.15, "comboResist": 0.09, "counterRate": 0.09, "dodgeResist": 0.16, "vampireRate": 0.1, "counterResist": 0.12, "vampireResist": 0.11, "critDamageBoost": 0.13, "resistanceBoost": 0.12, "critDamageReduce": 0.14, "finalDamageBoost": 0.15, "finalDamageReduce": 0.09}}, {"id": 1771671550387.9214, "name": "岩龟", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 5, "strength": 1, "constitution": 1, "intelligence": 6}, "experience": 0, "description": "坚不可摧的守护者", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 19, "attack": 38, "health": 303, "defense": 16, "critRate": 0.16, "stunRate": 0.14, "comboRate": 0.15, "dodgeRate": 0.14, "healBoost": 0.09, "critResist": 0.14, "stunResist": 0.16, "combatBoost": 0.1, "comboResist": 0.1, "counterRate": 0.09, "dodgeResist": 0.09, "vampireRate": 0.15, "counterResist": 0.15, "vampireResist": 0.15, "critDamageBoost": 0.09, "resistanceBoost": 0.09, "critDamageReduce": 0.13, "finalDamageBoost": 0.14, "finalDamageReduce": 0.1}}, {"id": 1771671550387.2554, "name": "云豹", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 3, "strength": 4, "constitution": 4, "intelligence": 8}, "experience": 0, "description": "敏捷的猎手", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 13, "attack": 28, "health": 237, "defense": 15, "critRate": 0.12, "stunRate": 0.12, "comboRate": 0.14, "dodgeRate": 0.1, "healBoost": 0.09, "critResist": 0.1, "stunResist": 0.13, "combatBoost": 0.1, "comboResist": 0.14, "counterRate": 0.1, "dodgeResist": 0.12, "vampireRate": 0.1, "counterResist": 0.12, "vampireResist": 0.08, "critDamageBoost": 0.08, "resistanceBoost": 0.08, "critDamageReduce": 0.11, "finalDamageBoost": 0.14, "finalDamageReduce": 0.11}}, {"id": 1771671550387.193, "name": "火鼠", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 1, "strength": 9, "constitution": 1, "intelligence": 4}, "experience": 0, "description": "活泼的啮齿类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 8, "attack": 12, "health": 112, "defense": 7, "critRate": 0.05, "stunRate": 0.08, "comboRate": 0.06, "dodgeRate": 0.06, "healBoost": 0.06, "critResist": 0.07, "stunResist": 0.06, "combatBoost": 0.05, "comboResist": 0.07, "counterRate": 0.08, "dodgeResist": 0.07, "vampireRate": 0.08, "counterResist": 0.05, "vampireResist": 0.08, "critDamageBoost": 0.08, "resistanceBoost": 0.07, "critDamageReduce": 0.09, "finalDamageBoost": 0.07, "finalDamageReduce": 0.1}}, {"id": 1771671550387.5693, "name": "灵猫", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 5, "strength": 6, "constitution": 7, "intelligence": 1}, "experience": 0, "description": "敏捷的小型焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 8, "attack": 13, "health": 113, "defense": 8, "critRate": 0.09, "stunRate": 0.09, "comboRate": 0.07, "dodgeRate": 0.09, "healBoost": 0.06, "critResist": 0.09, "stunResist": 0.07, "combatBoost": 0.07, "comboResist": 0.1, "counterRate": 0.06, "dodgeResist": 0.1, "vampireRate": 0.06, "counterResist": 0.07, "vampireResist": 0.05, "critDamageBoost": 0.09, "resistanceBoost": 0.07, "critDamageReduce": 0.07, "finalDamageBoost": 0.08, "finalDamageReduce": 0.1}}, {"id": 1771671550387.141, "name": "玄龟", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 8, "strength": 9, "constitution": 10, "intelligence": 7}, "experience": 0, "description": "擅长防御的水系焰兽", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 12, "attack": 27, "health": 224, "defense": 12, "critRate": 0.11, "stunRate": 0.13, "comboRate": 0.09, "dodgeRate": 0.14, "healBoost": 0.07, "critResist": 0.1, "stunResist": 0.13, "combatBoost": 0.13, "comboResist": 0.1, "counterRate": 0.13, "dodgeResist": 0.12, "vampireRate": 0.07, "counterResist": 0.14, "vampireResist": 0.08, "critDamageBoost": 0.08, "resistanceBoost": 0.1, "critDamageReduce": 0.08, "finalDamageBoost": 0.11, "finalDamageReduce": 0.13}}, {"id": 1771671550387.6062, "name": "云道符文戒2·天", "slot": "ring2", "type": "ring2", "level": 6, "stats": {"defense": 14, "resistanceBoost": 0.17, "critDamageReduce": 0.31}, "quality": "rare", "category": "equipment", "equipType": "ring2", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 6}, {"id": 1771671550387.9902, "name": "云雾裤子·道", "slot": "legs", "type": "legs", "level": 10, "stats": {"speed": 17, "defense": 20, "dodgeRate": 0.14}, "quality": "uncommon", "category": "equipment", "equipType": "legs", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 10}, {"id": 1771671550387.0647, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 7, "strength": 1, "constitution": 5, "intelligence": 7}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 9, "attack": 10, "health": 114, "defense": 7, "critRate": 0.07, "stunRate": 0.08, "comboRate": 0.1, "dodgeRate": 0.09, "healBoost": 0.07, "critResist": 0.08, "stunResist": 0.06, "combatBoost": 0.06, "comboResist": 0.06, "counterRate": 0.07, "dodgeResist": 0.08, "vampireRate": 0.06, "counterResist": 0.07, "vampireResist": 0.06, "critDamageBoost": 0.08, "resistanceBoost": 0.07, "critDamageReduce": 0.05, "finalDamageBoost": 0.1, "finalDamageReduce": 0.06}}, {"id": 1771671550387.83, "name": "紫金头部", "slot": "head", "type": "head", "level": 5, "stats": {"health": 119, "defense": 14, "stunResist": 0.13}, "quality": "common", "category": "equipment", "equipType": "head", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 5}, {"id": 1771671550387.1443, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 5, "strength": 7, "constitution": 7, "intelligence": 4}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 8, "attack": 13, "health": 113, "defense": 8, "critRate": 0.1, "stunRate": 0.1, "comboRate": 0.08, "dodgeRate": 0.08, "healBoost": 0.05, "critResist": 0.06, "stunResist": 0.05, "combatBoost": 0.06, "comboResist": 0.06, "counterRate": 0.07, "dodgeResist": 0.07, "vampireRate": 0.08, "counterResist": 0.1, "vampireResist": 0.09, "critDamageBoost": 0.1, "resistanceBoost": 0.1, "critDamageReduce": 0.06, "finalDamageBoost": 0.07, "finalDamageReduce": 0.05}}, {"id": 1771671550387.6843, "name": "幽魄焰心链", "slot": "necklace", "type": "necklace", "level": 13, "stats": {"health": 210, "healBoost": 0.25, "spiritRate": 0.35}, "quality": "common", "category": "equipment", "equipType": "necklace", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 13}, {"id": 1771671550387.5322, "name": "螭吻", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "celestial", "quality": {"agility": 8, "strength": 6, "constitution": 5, "intelligence": 8}, "experience": 0, "description": "龙之九子，形似鱼，能吞火，常立于屋脊", "upgradeItems": 4, "maxExperience": 100, "combatAttributes": {"speed": 33, "attack": 51, "health": 409, "defense": 29, "critRate": 0.15, "stunRate": 0.11, "comboRate": 0.15, "dodgeRate": 0.12, "healBoost": 0.18, "critResist": 0.17, "stunResist": 0.15, "combatBoost": 0.14, "comboResist": 0.17, "counterRate": 0.18, "dodgeResist": 0.17, "vampireRate": 0.18, "counterResist": 0.16, "vampireResist": 0.14, "critDamageBoost": 0.15, "resistanceBoost": 0.1, "critDamageReduce": 0.12, "finalDamageBoost": 0.18, "finalDamageReduce": 0.16}}, {"id": 1771671550387.017, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 9, "strength": 3, "constitution": 8, "intelligence": 3}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 7, "attack": 15, "health": 100, "defense": 8, "critRate": 0.1, "stunRate": 0.06, "comboRate": 0.09, "dodgeRate": 0.09, "healBoost": 0.07, "critResist": 0.1, "stunResist": 0.06, "combatBoost": 0.1, "comboResist": 0.05, "counterRate": 0.08, "dodgeResist": 0.07, "vampireRate": 0.05, "counterResist": 0.1, "vampireResist": 0.09, "critDamageBoost": 0.07, "resistanceBoost": 0.08, "critDamageReduce": 0.07, "finalDamageBoost": 0.09, "finalDamageReduce": 0.07}}, {"id": 1771671550387.98, "name": "赤金手套·仙", "slot": "hands", "type": "hands", "level": 10, "stats": {"attack": 27, "critRate": 0.3, "comboRate": 0.26}, "quality": "epic", "category": "equipment", "equipType": "hands", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 10}, {"id": 1771671550387.9111, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 7, "strength": 2, "constitution": 3, "intelligence": 7}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 7, "attack": 15, "health": 101, "defense": 8, "critRate": 0.07, "stunRate": 0.07, "comboRate": 0.08, "dodgeRate": 0.06, "healBoost": 0.08, "critResist": 0.07, "stunResist": 0.05, "combatBoost": 0.06, "comboResist": 0.1, "counterRate": 0.08, "dodgeResist": 0.08, "vampireRate": 0.09, "counterResist": 0.05, "vampireResist": 0.08, "critDamageBoost": 0.09, "resistanceBoost": 0.1, "critDamageReduce": 0.1, "finalDamageBoost": 0.08, "finalDamageReduce": 0.08}}, {"id": 1771671550387.1304, "name": "玄阳衣服·道", "slot": "body", "type": "body", "level": 10, "stats": {"health": 228, "defense": 23, "finalDamageReduce": 0.21}, "quality": "uncommon", "category": "equipment", "equipType": "body", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 10}, {"id": 1771671550387.822, "name": "玄风鞋子·道", "slot": "feet", "type": "feet", "level": 13, "stats": {"speed": 32, "defense": 19, "dodgeRate": 0.15}, "quality": "uncommon", "category": "equipment", "equipType": "feet", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 13}, {"id": 1771671550387.4773, "name": "火鼠", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 7, "strength": 3, "constitution": 10, "intelligence": 5}, "experience": 0, "description": "活泼的啮齿类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 7, "attack": 10, "health": 108, "defense": 6, "critRate": 0.08, "stunRate": 0.07, "comboRate": 0.06, "dodgeRate": 0.07, "healBoost": 0.06, "critResist": 0.09, "stunResist": 0.06, "combatBoost": 0.05, "comboResist": 0.09, "counterRate": 0.06, "dodgeResist": 0.07, "vampireRate": 0.07, "counterResist": 0.07, "vampireResist": 0.08, "critDamageBoost": 0.06, "resistanceBoost": 0.07, "critDamageReduce": 0.06, "finalDamageBoost": 0.08, "finalDamageReduce": 0.07}}, {"id": 1771671550387.7256, "name": "九天焰杖·道", "slot": "weapon", "type": "weapon", "level": 3, "stats": {"attack": 16, "critRate": 0.14, "critDamageBoost": 0.27}, "quality": "uncommon", "category": "equipment", "equipType": "weapon", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 3}, {"id": 1771671550387.203, "name": "云霄头部·天", "slot": "head", "type": "head", "level": 6, "stats": {"health": 172, "defense": 23, "stunResist": 0.23}, "quality": "rare", "category": "equipment", "equipType": "head", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 6}, {"id": 1771671550387.2922, "name": "冰狼", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 10, "strength": 1, "constitution": 6, "intelligence": 7}, "experience": 0, "description": "冰原霸主", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 26, "attack": 44, "health": 328, "defense": 22, "critRate": 0.11, "stunRate": 0.14, "comboRate": 0.14, "dodgeRate": 0.11, "healBoost": 0.13, "critResist": 0.16, "stunResist": 0.15, "combatBoost": 0.13, "comboResist": 0.13, "counterRate": 0.08, "dodgeResist": 0.11, "vampireRate": 0.15, "counterResist": 0.16, "vampireResist": 0.15, "critDamageBoost": 0.13, "resistanceBoost": 0.1, "critDamageReduce": 0.11, "finalDamageBoost": 0.15, "finalDamageReduce": 0.15}}, {"id": 1771671550387.1348, "name": "天珠焰心链", "slot": "necklace", "type": "necklace", "level": 9, "stats": {"health": 177, "healBoost": 0.2, "spiritRate": 0.3}, "quality": "common", "category": "equipment", "equipType": "necklace", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 9}, {"id": 1771671550387.9136, "name": "幽钢护腕·道", "slot": "wrist", "type": "wrist", "level": 10, "stats": {"defense": 17, "counterRate": 0.16, "vampireRate": 0.15}, "quality": "uncommon", "category": "equipment", "equipType": "wrist", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 10}, {"id": 1771671550387.4053, "name": "青锋肩甲", "slot": "shoulder", "type": "shoulder", "level": 6, "stats": {"health": 65, "defense": 16, "counterRate": 0.1}, "quality": "common", "category": "equipment", "equipType": "shoulder", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 6}, {"id": 1771671550387.871, "name": "云踪鞋子", "slot": "feet", "type": "feet", "level": 12, "stats": {"speed": 30, "defense": 11, "dodgeRate": 0.12}, "quality": "common", "category": "equipment", "equipType": "feet", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 12}, {"id": 1771671550387.8171, "name": "玄龟", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 10, "strength": 5, "constitution": 7, "intelligence": 1}, "experience": 0, "description": "擅长防御的水系焰兽", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 14, "attack": 22, "health": 221, "defense": 15, "critRate": 0.08, "stunRate": 0.08, "comboRate": 0.13, "dodgeRate": 0.1, "healBoost": 0.11, "critResist": 0.09, "stunResist": 0.07, "combatBoost": 0.1, "comboResist": 0.11, "counterRate": 0.1, "dodgeResist": 0.12, "vampireRate": 0.08, "counterResist": 0.09, "vampireResist": 0.1, "critDamageBoost": 0.11, "resistanceBoost": 0.09, "critDamageReduce": 0.13, "finalDamageBoost": 0.14, "finalDamageReduce": 0.12}}, {"id": 1771671550387.2122, "name": "混元衣服·天", "slot": "body", "type": "body", "level": 4, "stats": {"health": 249, "defense": 17, "finalDamageReduce": 0.18}, "quality": "rare", "category": "equipment", "equipType": "body", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 4}, {"id": 1771671550387.4995, "name": "云珠焰心链·道", "slot": "necklace", "type": "necklace", "level": 13, "stats": {"health": 211, "healBoost": 0.54, "spiritRate": 0.43}, "quality": "uncommon", "category": "equipment", "equipType": "necklace", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 13}, {"id": 1771671550387.0796, "name": "云雾裤子·仙", "slot": "legs", "type": "legs", "level": 10, "stats": {"speed": 24, "defense": 24, "dodgeRate": 0.23}, "quality": "epic", "category": "equipment", "equipType": "legs", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 10}, {"id": 1771671550387.6243, "name": "火鼠", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 5, "strength": 8, "constitution": 10, "intelligence": 6}, "experience": 0, "description": "活泼的啮齿类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 8, "attack": 14, "health": 118, "defense": 8, "critRate": 0.1, "stunRate": 0.1, "comboRate": 0.06, "dodgeRate": 0.08, "healBoost": 0.05, "critResist": 0.06, "stunResist": 0.06, "combatBoost": 0.05, "comboResist": 0.07, "counterRate": 0.07, "dodgeResist": 0.09, "vampireRate": 0.08, "counterResist": 0.1, "vampireResist": 0.09, "critDamageBoost": 0.06, "resistanceBoost": 0.07, "critDamageReduce": 0.07, "finalDamageBoost": 0.07, "finalDamageReduce": 0.09}}, {"id": 1771671550387.7537, "name": "赤命符文戒1", "slot": "ring1", "type": "ring1", "level": 4, "stats": {"attack": 9, "critDamageBoost": 0.15, "finalDamageBoost": 0.08}, "quality": "common", "category": "equipment", "equipType": "ring1", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 4}, {"id": 1771671550387.2207, "name": "岩龟", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 1, "strength": 3, "constitution": 5, "intelligence": 4}, "experience": 0, "description": "坚不可摧的守护者", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 26, "attack": 39, "health": 317, "defense": 19, "critRate": 0.09, "stunRate": 0.1, "comboRate": 0.16, "dodgeRate": 0.12, "healBoost": 0.11, "critResist": 0.11, "stunResist": 0.09, "combatBoost": 0.12, "comboResist": 0.09, "counterRate": 0.08, "dodgeResist": 0.13, "vampireRate": 0.16, "counterResist": 0.14, "vampireResist": 0.13, "critDamageBoost": 0.14, "resistanceBoost": 0.14, "critDamageReduce": 0.09, "finalDamageBoost": 0.11, "finalDamageReduce": 0.13}}, {"id": 1771671550387.3772, "name": "云豹", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 7, "strength": 2, "constitution": 8, "intelligence": 3}, "experience": 0, "description": "敏捷的猎手", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 12, "attack": 22, "health": 236, "defense": 14, "critRate": 0.11, "stunRate": 0.07, "comboRate": 0.07, "dodgeRate": 0.14, "healBoost": 0.12, "critResist": 0.07, "stunResist": 0.1, "combatBoost": 0.14, "comboResist": 0.1, "counterRate": 0.09, "dodgeResist": 0.13, "vampireRate": 0.08, "counterResist": 0.09, "vampireResist": 0.11, "critDamageBoost": 0.07, "resistanceBoost": 0.11, "critDamageReduce": 0.13, "finalDamageBoost": 0.12, "finalDamageReduce": 0.11}}, {"id": 1771671550387.43, "name": "青命符文戒1", "slot": "ring1", "type": "ring1", "level": 11, "stats": {"attack": 18, "critDamageBoost": 0.38, "finalDamageBoost": 0.16}, "quality": "common", "category": "equipment", "equipType": "ring1", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 11}, {"id": 1771671550387.2954, "name": "负屃", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "celestial", "quality": {"agility": 9, "strength": 3, "constitution": 2, "intelligence": 5}, "experience": 0, "description": "龙之八子，形似龙，雅好诗文，常盘于碑顶", "upgradeItems": 4, "maxExperience": 100, "combatAttributes": {"speed": 36, "attack": 59, "health": 427, "defense": 22, "critRate": 0.18, "stunRate": 0.1, "comboRate": 0.18, "dodgeRate": 0.11, "healBoost": 0.11, "critResist": 0.14, "stunResist": 0.12, "combatBoost": 0.14, "comboResist": 0.11, "counterRate": 0.11, "dodgeResist": 0.15, "vampireRate": 0.18, "counterResist": 0.11, "vampireResist": 0.13, "critDamageBoost": 0.15, "resistanceBoost": 0.18, "critDamageReduce": 0.11, "finalDamageBoost": 0.12, "finalDamageReduce": 0.16}}, {"id": 1771671550387.5205, "name": "云豹", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 6, "strength": 1, "constitution": 2, "intelligence": 1}, "experience": 0, "description": "敏捷的猎手", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 18, "attack": 25, "health": 216, "defense": 12, "critRate": 0.09, "stunRate": 0.11, "comboRate": 0.09, "dodgeRate": 0.12, "healBoost": 0.11, "critResist": 0.07, "stunResist": 0.13, "combatBoost": 0.12, "comboResist": 0.11, "counterRate": 0.12, "dodgeResist": 0.11, "vampireRate": 0.13, "counterResist": 0.08, "vampireResist": 0.11, "critDamageBoost": 0.09, "resistanceBoost": 0.12, "critDamageReduce": 0.1, "finalDamageBoost": 0.11, "finalDamageReduce": 0.12}}, {"id": 1771671550387.4868, "name": "草兔", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 9, "strength": 1, "constitution": 6, "intelligence": 10}, "experience": 0, "description": "温顺的兔类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 9, "attack": 15, "health": 116, "defense": 6, "critRate": 0.1, "stunRate": 0.07, "comboRate": 0.1, "dodgeRate": 0.07, "healBoost": 0.09, "critResist": 0.06, "stunResist": 0.07, "combatBoost": 0.07, "comboResist": 0.06, "counterRate": 0.09, "dodgeResist": 0.08, "vampireRate": 0.07, "counterResist": 0.08, "vampireResist": 0.06, "critDamageBoost": 0.07, "resistanceBoost": 0.08, "critDamageReduce": 0.06, "finalDamageBoost": 0.09, "finalDamageReduce": 0.07}}, {"id": 1771671550387.4758, "name": "云豹", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 9, "strength": 10, "constitution": 1, "intelligence": 1}, "experience": 0, "description": "敏捷的猎手", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 15, "attack": 22, "health": 217, "defense": 14, "critRate": 0.1, "stunRate": 0.08, "comboRate": 0.13, "dodgeRate": 0.14, "healBoost": 0.14, "critResist": 0.1, "stunResist": 0.09, "combatBoost": 0.09, "comboResist": 0.1, "counterRate": 0.07, "dodgeResist": 0.1, "vampireRate": 0.07, "counterResist": 0.07, "vampireResist": 0.11, "critDamageBoost": 0.08, "resistanceBoost": 0.07, "critDamageReduce": 0.08, "finalDamageBoost": 0.11, "finalDamageReduce": 0.08}}, {"id": 1771671550387.8193, "name": "灵猫", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 7, "strength": 7, "constitution": 3, "intelligence": 9}, "experience": 0, "description": "敏捷的小型焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 6, "attack": 15, "health": 105, "defense": 8, "critRate": 0.09, "stunRate": 0.09, "comboRate": 0.1, "dodgeRate": 0.09, "healBoost": 0.07, "critResist": 0.09, "stunResist": 0.09, "combatBoost": 0.07, "comboResist": 0.07, "counterRate": 0.09, "dodgeResist": 0.09, "vampireRate": 0.05, "counterResist": 0.09, "vampireResist": 0.09, "critDamageBoost": 0.07, "resistanceBoost": 0.07, "critDamageReduce": 0.08, "finalDamageBoost": 0.05, "finalDamageReduce": 0.08}}, {"id": 1771671550387.4424, "name": "玄宝焰器·道", "slot": "artifact", "type": "artifact", "level": 3, "stats": {"attack": 0, "critRate": 0.23, "comboRate": 0.16}, "quality": "uncommon", "category": "equipment", "equipType": "artifact", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 3}, {"id": 1771671550387.47, "name": "太素衣服·仙", "slot": "body", "type": "body", "level": 3, "stats": {"health": 306, "defense": 29, "finalDamageReduce": 0.18}, "quality": "epic", "category": "equipment", "equipType": "body", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 3}, {"id": 1771671550387.5312, "name": "玄龟", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 1, "strength": 1, "constitution": 8, "intelligence": 4}, "experience": 0, "description": "擅长防御的水系焰兽", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 14, "attack": 21, "health": 219, "defense": 15, "critRate": 0.12, "stunRate": 0.08, "comboRate": 0.13, "dodgeRate": 0.1, "healBoost": 0.08, "critResist": 0.13, "stunResist": 0.13, "combatBoost": 0.12, "comboResist": 0.1, "counterRate": 0.1, "dodgeResist": 0.1, "vampireRate": 0.11, "counterResist": 0.13, "vampireResist": 0.08, "critDamageBoost": 0.12, "resistanceBoost": 0.09, "critDamageReduce": 0.11, "finalDamageBoost": 0.1, "finalDamageReduce": 0.1}}, {"id": 1771671550387.3005, "name": "混元衣服·仙", "slot": "body", "type": "body", "level": 7, "stats": {"health": 412, "defense": 36, "finalDamageReduce": 0.18}, "quality": "epic", "category": "equipment", "equipType": "body", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 7}, {"id": 1771671550387.9797, "name": "火鼠", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 3, "strength": 3, "constitution": 3, "intelligence": 6}, "experience": 0, "description": "活泼的啮齿类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 9, "attack": 11, "health": 107, "defense": 7, "critRate": 0.08, "stunRate": 0.1, "comboRate": 0.07, "dodgeRate": 0.07, "healBoost": 0.08, "critResist": 0.05, "stunResist": 0.08, "combatBoost": 0.07, "comboResist": 0.06, "counterRate": 0.05, "dodgeResist": 0.06, "vampireRate": 0.1, "counterResist": 0.09, "vampireResist": 0.09, "critDamageBoost": 0.06, "resistanceBoost": 0.07, "critDamageReduce": 0.1, "finalDamageBoost": 0.08, "finalDamageReduce": 0.07}}, {"id": 1771671550387.4897, "name": "赤金手套·仙", "slot": "hands", "type": "hands", "level": 7, "stats": {"attack": 32, "critRate": 0.17, "comboRate": 0.23}, "quality": "epic", "category": "equipment", "equipType": "hands", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 7}, {"id": 1771671550387.554, "name": "幽银手套", "slot": "hands", "type": "hands", "level": 7, "stats": {"attack": 12, "critRate": 0.08, "comboRate": 0.13}, "quality": "common", "category": "equipment", "equipType": "hands", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 7}, {"id": 1771671550387.976, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 10, "strength": 3, "constitution": 7, "intelligence": 10}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 7, "attack": 13, "health": 119, "defense": 8, "critRate": 0.09, "stunRate": 0.06, "comboRate": 0.09, "dodgeRate": 0.08, "healBoost": 0.09, "critResist": 0.07, "stunResist": 0.07, "combatBoost": 0.09, "comboResist": 0.08, "counterRate": 0.07, "dodgeResist": 0.06, "vampireRate": 0.08, "counterResist": 0.08, "vampireResist": 0.06, "critDamageBoost": 0.07, "resistanceBoost": 0.07, "critDamageReduce": 0.07, "finalDamageBoost": 0.06, "finalDamageReduce": 0.07}}, {"id": 1771671550387.2988, "name": "雷鹰", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 9, "strength": 2, "constitution": 2, "intelligence": 1}, "experience": 0, "description": "雷电的猛禽", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 25, "attack": 37, "health": 327, "defense": 17, "critRate": 0.08, "stunRate": 0.08, "comboRate": 0.15, "dodgeRate": 0.11, "healBoost": 0.12, "critResist": 0.14, "stunResist": 0.09, "combatBoost": 0.13, "comboResist": 0.15, "counterRate": 0.09, "dodgeResist": 0.08, "vampireRate": 0.15, "counterResist": 0.13, "vampireResist": 0.09, "critDamageBoost": 0.11, "resistanceBoost": 0.15, "critDamageReduce": 0.08, "finalDamageBoost": 0.1, "finalDamageReduce": 0.11}}, {"id": 1771671550387.8296, "name": "草兔", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 2, "strength": 4, "constitution": 3, "intelligence": 6}, "experience": 0, "description": "温顺的兔类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 8, "attack": 12, "health": 105, "defense": 6, "critRate": 0.1, "stunRate": 0.06, "comboRate": 0.09, "dodgeRate": 0.08, "healBoost": 0.08, "critResist": 0.06, "stunResist": 0.1, "combatBoost": 0.06, "comboResist": 0.07, "counterRate": 0.08, "dodgeResist": 0.05, "vampireRate": 0.09, "counterResist": 0.1, "vampireResist": 0.06, "critDamageBoost": 0.08, "resistanceBoost": 0.05, "critDamageReduce": 0.06, "finalDamageBoost": 0.05, "finalDamageReduce": 0.06}}, {"id": 1771671550387.867, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 3, "strength": 2, "constitution": 5, "intelligence": 5}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 9, "attack": 15, "health": 117, "defense": 6, "critRate": 0.09, "stunRate": 0.07, "comboRate": 0.07, "dodgeRate": 0.07, "healBoost": 0.05, "critResist": 0.1, "stunResist": 0.07, "combatBoost": 0.05, "comboResist": 0.09, "counterRate": 0.08, "dodgeResist": 0.06, "vampireRate": 0.06, "counterResist": 0.05, "vampireResist": 0.08, "critDamageBoost": 0.07, "resistanceBoost": 0.09, "critDamageReduce": 0.07, "finalDamageBoost": 0.06, "finalDamageReduce": 0.08}}, {"id": 1771671550387.886, "name": "九天焰杖·天", "slot": "weapon", "type": "weapon", "level": 12, "stats": {"attack": 39, "critRate": 0.32, "critDamageBoost": 0.41}, "quality": "rare", "category": "equipment", "equipType": "weapon", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 12}, {"id": 1771671550387.9841, "name": "星光裤子·天", "slot": "legs", "type": "legs", "level": 8, "stats": {"speed": 14, "defense": 31, "dodgeRate": 0.24}, "quality": "rare", "category": "equipment", "equipType": "legs", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 8}, {"id": 1771671550387.666, "name": "草兔", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 7, "strength": 3, "constitution": 5, "intelligence": 4}, "experience": 0, "description": "温顺的兔类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 7, "attack": 12, "health": 103, "defense": 8, "critRate": 0.05, "stunRate": 0.09, "comboRate": 0.1, "dodgeRate": 0.07, "healBoost": 0.07, "critResist": 0.06, "stunResist": 0.06, "combatBoost": 0.08, "comboResist": 0.09, "counterRate": 0.08, "dodgeResist": 0.07, "vampireRate": 0.06, "counterResist": 0.07, "vampireResist": 0.08, "critDamageBoost": 0.09, "resistanceBoost": 0.08, "critDamageReduce": 0.1, "finalDamageBoost": 0.07, "finalDamageReduce": 0.1}}, {"id": 1771671550387.2104, "name": "地甲", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 8, "strength": 4, "constitution": 8, "intelligence": 1}, "experience": 0, "description": "坚固的大地守护者", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 14, "attack": 28, "health": 230, "defense": 13, "critRate": 0.13, "stunRate": 0.12, "comboRate": 0.09, "dodgeRate": 0.11, "healBoost": 0.12, "critResist": 0.08, "stunResist": 0.1, "combatBoost": 0.11, "comboResist": 0.12, "counterRate": 0.08, "dodgeResist": 0.11, "vampireRate": 0.08, "counterResist": 0.11, "vampireResist": 0.07, "critDamageBoost": 0.12, "resistanceBoost": 0.07, "critDamageReduce": 0.08, "finalDamageBoost": 0.13, "finalDamageReduce": 0.1}}, {"id": 1771671550387.0518, "name": "星宝焰器·道", "slot": "artifact", "type": "artifact", "level": 13, "stats": {"attack": 1, "critRate": 0.63, "comboRate": 0.71}, "quality": "uncommon", "category": "equipment", "equipType": "artifact", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 13}, {"id": 1771671550387.3079, "name": "云雾裤子", "slot": "legs", "type": "legs", "level": 6, "stats": {"speed": 14, "defense": 10, "dodgeRate": 0.14}, "quality": "common", "category": "equipment", "equipType": "legs", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 6}, {"id": 1771671550387.938, "name": "玄圣焰心链", "slot": "necklace", "type": "necklace", "level": 7, "stats": {"health": 123, "healBoost": 0.31, "spiritRate": 0.24}, "quality": "common", "category": "equipment", "equipType": "necklace", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 7}, {"id": 1771671550387.8188, "name": "赤金手套·天", "slot": "hands", "type": "hands", "level": 4, "stats": {"attack": 18, "critRate": 0.12, "comboRate": 0.2}, "quality": "rare", "category": "equipment", "equipType": "hands", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 4}, {"id": 1771671550387.6348, "name": "紫系腰带·道", "slot": "belt", "type": "belt", "level": 5, "stats": {"health": 77, "defense": 9, "combatBoost": 0.18}, "quality": "uncommon", "category": "equipment", "equipType": "belt", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 5}, {"id": 1771671550387.749, "name": "天珠焰心链", "slot": "necklace", "type": "necklace", "level": 6, "stats": {"health": 127, "healBoost": 0.2, "spiritRate": 0.2}, "quality": "common", "category": "equipment", "equipType": "necklace", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 6}, {"id": 1771671550387.9387, "name": "草兔", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 8, "strength": 7, "constitution": 3, "intelligence": 9}, "experience": 0, "description": "温顺的兔类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 7, "attack": 13, "health": 114, "defense": 7, "critRate": 0.07, "stunRate": 0.08, "comboRate": 0.07, "dodgeRate": 0.08, "healBoost": 0.08, "critResist": 0.06, "stunResist": 0.07, "combatBoost": 0.08, "comboResist": 0.06, "counterRate": 0.09, "dodgeResist": 0.09, "vampireRate": 0.1, "counterResist": 0.09, "vampireResist": 0.1, "critDamageBoost": 0.09, "resistanceBoost": 0.09, "critDamageReduce": 0.08, "finalDamageBoost": 0.05, "finalDamageReduce": 0.09}}, {"id": 1771671550387.961, "name": "火凤凰", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 6, "strength": 7, "constitution": 4, "intelligence": 1}, "experience": 0, "description": "浴火重生的永恒之鸟", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 23, "attack": 36, "health": 358, "defense": 18, "critRate": 0.12, "stunRate": 0.13, "comboRate": 0.12, "dodgeRate": 0.09, "healBoost": 0.14, "critResist": 0.14, "stunResist": 0.12, "combatBoost": 0.14, "comboResist": 0.1, "counterRate": 0.13, "dodgeResist": 0.12, "vampireRate": 0.11, "counterResist": 0.1, "vampireResist": 0.09, "critDamageBoost": 0.1, "resistanceBoost": 0.13, "critDamageReduce": 0.11, "finalDamageBoost": 0.1, "finalDamageReduce": 0.14}}, {"id": 1771671550387.9258, "name": "天绝护腕·天", "slot": "wrist", "type": "wrist", "level": 7, "stats": {"defense": 14, "counterRate": 0.25, "vampireRate": 0.19}, "quality": "rare", "category": "equipment", "equipType": "wrist", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 7}, {"id": 1771671550387.3115, "name": "青莲鞋子·圣", "slot": "feet", "type": "feet", "level": 5, "stats": {"speed": 32, "defense": 30, "dodgeRate": 0.37}, "quality": "legendary", "category": "equipment", "equipType": "feet", "qualityInfo": {"name": "极品", "color": "#ff9800", "statMod": 2.5, "maxStatMod": 3.5}, "requiredRealm": 5}, {"id": 1771671550387.321, "name": "地甲", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 1, "strength": 6, "constitution": 4, "intelligence": 6}, "experience": 0, "description": "坚固的大地守护者", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 15, "attack": 29, "health": 211, "defense": 14, "critRate": 0.13, "stunRate": 0.11, "comboRate": 0.11, "dodgeRate": 0.08, "healBoost": 0.1, "critResist": 0.11, "stunResist": 0.12, "combatBoost": 0.13, "comboResist": 0.1, "counterRate": 0.14, "dodgeResist": 0.08, "vampireRate": 0.09, "counterResist": 0.12, "vampireResist": 0.09, "critDamageBoost": 0.11, "resistanceBoost": 0.11, "critDamageReduce": 0.09, "finalDamageBoost": 0.08, "finalDamageReduce": 0.12}}, {"id": 1771671550387.189, "name": "赤命符文戒1·道", "slot": "ring1", "type": "ring1", "level": 12, "stats": {"attack": 22, "critDamageBoost": 0.37, "finalDamageBoost": 0.21}, "quality": "uncommon", "category": "equipment", "equipType": "ring1", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 12}, {"id": 1771671550387.9033, "name": "赤炎焰杖", "slot": "weapon", "type": "weapon", "level": 4, "stats": {"attack": 15, "critRate": 0.14, "critDamageBoost": 0.26}, "quality": "common", "category": "equipment", "equipType": "weapon", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 4}, {"id": 1771671550387.3376, "name": "青系腰带·道", "slot": "belt", "type": "belt", "level": 7, "stats": {"health": 130, "defense": 10, "combatBoost": 0.16}, "quality": "uncommon", "category": "equipment", "equipType": "belt", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 7}, {"id": 1771671550387.9429, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 7, "strength": 8, "constitution": 5, "intelligence": 7}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 8, "attack": 12, "health": 114, "defense": 7, "critRate": 0.1, "stunRate": 0.08, "comboRate": 0.07, "dodgeRate": 0.08, "healBoost": 0.08, "critResist": 0.05, "stunResist": 0.05, "combatBoost": 0.08, "comboResist": 0.06, "counterRate": 0.08, "dodgeResist": 0.07, "vampireRate": 0.05, "counterResist": 0.08, "vampireResist": 0.09, "critDamageBoost": 0.09, "resistanceBoost": 0.07, "critDamageReduce": 0.05, "finalDamageBoost": 0.07, "finalDamageReduce": 0.07}}, {"id": 1771671550387.2876, "name": "玄命符文戒1·道", "slot": "ring1", "type": "ring1", "level": 8, "stats": {"attack": 18, "critDamageBoost": 0.24, "finalDamageBoost": 0.19}, "quality": "uncommon", "category": "equipment", "equipType": "ring1", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 8}, {"id": 1771671550387.1743, "name": "天珠焰心链", "slot": "necklace", "type": "necklace", "level": 7, "stats": {"health": 142, "healBoost": 0.28, "spiritRate": 0.28}, "quality": "common", "category": "equipment", "equipType": "necklace", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 7}, {"id": 1771671550387.9436, "name": "火鼠", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 7, "strength": 6, "constitution": 8, "intelligence": 8}, "experience": 0, "description": "活泼的啮齿类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 7, "attack": 14, "health": 108, "defense": 5, "critRate": 0.09, "stunRate": 0.09, "comboRate": 0.08, "dodgeRate": 0.09, "healBoost": 0.06, "critResist": 0.06, "stunResist": 0.09, "combatBoost": 0.09, "comboResist": 0.08, "counterRate": 0.09, "dodgeResist": 0.06, "vampireRate": 0.09, "counterResist": 0.1, "vampireResist": 0.07, "critDamageBoost": 0.08, "resistanceBoost": 0.07, "critDamageReduce": 0.06, "finalDamageBoost": 0.07, "finalDamageReduce": 0.06}}, {"id": 1771671550387.584, "name": "赤铜护腕·道", "slot": "wrist", "type": "wrist", "level": 8, "stats": {"defense": 10, "counterRate": 0.18, "vampireRate": 0.15}, "quality": "uncommon", "category": "equipment", "equipType": "wrist", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 8}, {"id": 1771671550387.1716, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 4, "strength": 10, "constitution": 9, "intelligence": 1}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 9, "attack": 12, "health": 118, "defense": 7, "critRate": 0.08, "stunRate": 0.08, "comboRate": 0.07, "dodgeRate": 0.05, "healBoost": 0.08, "critResist": 0.07, "stunResist": 0.09, "combatBoost": 0.1, "comboResist": 0.06, "counterRate": 0.07, "dodgeResist": 0.1, "vampireRate": 0.1, "counterResist": 0.09, "vampireResist": 0.09, "critDamageBoost": 0.06, "resistanceBoost": 0.1, "critDamageReduce": 0.07, "finalDamageBoost": 0.09, "finalDamageReduce": 0.07}}, {"id": 1771671550387.1511, "name": "青龙衣服", "slot": "body", "type": "body", "level": 4, "stats": {"health": 152, "defense": 18, "finalDamageReduce": 0.1}, "quality": "common", "category": "equipment", "equipType": "body", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 4}, {"id": 1771671550387.5928, "name": "赤道符文戒2", "slot": "ring2", "type": "ring2", "level": 11, "stats": {"defense": 11, "resistanceBoost": 0.11, "critDamageReduce": 0.37}, "quality": "common", "category": "equipment", "equipType": "ring2", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 11}, {"id": 1771671550387.1677, "name": "风隼", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 7, "strength": 5, "constitution": 9, "intelligence": 7}, "experience": 0, "description": "速度极快的飞行焰兽", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 17, "attack": 22, "health": 220, "defense": 14, "critRate": 0.1, "stunRate": 0.12, "comboRate": 0.07, "dodgeRate": 0.1, "healBoost": 0.1, "critResist": 0.07, "stunResist": 0.1, "combatBoost": 0.1, "comboResist": 0.08, "counterRate": 0.08, "dodgeResist": 0.14, "vampireRate": 0.11, "counterResist": 0.14, "vampireResist": 0.07, "critDamageBoost": 0.11, "resistanceBoost": 0.13, "critDamageReduce": 0.1, "finalDamageBoost": 0.12, "finalDamageReduce": 0.14}}, {"id": 1771671550387.946, "name": "玄龟", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 5, "strength": 7, "constitution": 6, "intelligence": 5}, "experience": 0, "description": "擅长防御的水系焰兽", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 13, "attack": 28, "health": 214, "defense": 10, "critRate": 0.12, "stunRate": 0.1, "comboRate": 0.11, "dodgeRate": 0.13, "healBoost": 0.13, "critResist": 0.13, "stunResist": 0.14, "combatBoost": 0.07, "comboResist": 0.13, "counterRate": 0.1, "dodgeResist": 0.13, "vampireRate": 0.11, "counterResist": 0.09, "vampireResist": 0.09, "critDamageBoost": 0.14, "resistanceBoost": 0.14, "critDamageReduce": 0.12, "finalDamageBoost": 0.13, "finalDamageReduce": 0.08}}, {"id": 1771671550387.812, "name": "赤炎焰杖·天", "slot": "weapon", "type": "weapon", "level": 12, "stats": {"attack": 46, "critRate": 0.17, "critDamageBoost": 0.58}, "quality": "rare", "category": "equipment", "equipType": "weapon", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 12}, {"id": 1771671550387.6099, "name": "星光裤子", "slot": "legs", "type": "legs", "level": 13, "stats": {"speed": 16, "defense": 16, "dodgeRate": 0.16}, "quality": "common", "category": "equipment", "equipType": "legs", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 13}, {"id": 1771671550387.5217, "name": "玄铁护腕", "slot": "wrist", "type": "wrist", "level": 4, "stats": {"defense": 9, "counterRate": 0.13, "vampireRate": 0.11}, "quality": "common", "category": "equipment", "equipType": "wrist", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 4}, {"id": 1771671550387.9197, "name": "紫电裤子", "slot": "legs", "type": "legs", "level": 9, "stats": {"speed": 17, "defense": 20, "dodgeRate": 0.14}, "quality": "common", "category": "equipment", "equipType": "legs", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 9}, {"id": 1771671550387.6511, "name": "星道符文戒2·道", "slot": "ring2", "type": "ring2", "level": 7, "stats": {"defense": 11, "resistanceBoost": 0.17, "critDamageReduce": 0.32}, "quality": "uncommon", "category": "equipment", "equipType": "ring2", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 7}, {"id": 1771671550387.1348, "name": "星宝焰器", "slot": "artifact", "type": "artifact", "level": 8, "stats": {"attack": 0, "critRate": 0.37, "comboRate": 0.52}, "quality": "common", "category": "equipment", "equipType": "artifact", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 8}, {"id": 1771671550387.075, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 9, "strength": 10, "constitution": 4, "intelligence": 9}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 7, "attack": 15, "health": 110, "defense": 7, "critRate": 0.05, "stunRate": 0.08, "comboRate": 0.08, "dodgeRate": 0.1, "healBoost": 0.08, "critResist": 0.06, "stunResist": 0.08, "combatBoost": 0.07, "comboResist": 0.07, "counterRate": 0.09, "dodgeResist": 0.08, "vampireRate": 0.1, "counterResist": 0.06, "vampireResist": 0.06, "critDamageBoost": 0.09, "resistanceBoost": 0.06, "critDamageReduce": 0.07, "finalDamageBoost": 0.08, "finalDamageReduce": 0.08}}, {"id": 1771671550387.6975, "name": "风隼", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 5, "strength": 10, "constitution": 9, "intelligence": 8}, "experience": 0, "description": "速度极快的飞行焰兽", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 12, "attack": 22, "health": 214, "defense": 15, "critRate": 0.09, "stunRate": 0.1, "comboRate": 0.08, "dodgeRate": 0.13, "healBoost": 0.11, "critResist": 0.07, "stunResist": 0.08, "combatBoost": 0.13, "comboResist": 0.14, "counterRate": 0.1, "dodgeResist": 0.08, "vampireRate": 0.12, "counterResist": 0.12, "vampireResist": 0.09, "critDamageBoost": 0.13, "resistanceBoost": 0.07, "critDamageReduce": 0.09, "finalDamageBoost": 0.14, "finalDamageReduce": 0.1}}, {"id": 1771671550387.5603, "name": "冰狼", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 6, "strength": 6, "constitution": 1, "intelligence": 1}, "experience": 0, "description": "冰原霸主", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 20, "attack": 32, "health": 348, "defense": 21, "critRate": 0.09, "stunRate": 0.12, "comboRate": 0.15, "dodgeRate": 0.16, "healBoost": 0.1, "critResist": 0.12, "stunResist": 0.13, "combatBoost": 0.15, "comboResist": 0.11, "counterRate": 0.12, "dodgeResist": 0.13, "vampireRate": 0.1, "counterResist": 0.12, "vampireResist": 0.11, "critDamageBoost": 0.09, "resistanceBoost": 0.08, "critDamageReduce": 0.14, "finalDamageBoost": 0.14, "finalDamageReduce": 0.09}}, {"id": 1771671550387.123, "name": "灵猫", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 7, "strength": 2, "constitution": 9, "intelligence": 5}, "experience": 0, "description": "敏捷的小型焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 6, "attack": 13, "health": 101, "defense": 5, "critRate": 0.06, "stunRate": 0.07, "comboRate": 0.05, "dodgeRate": 0.06, "healBoost": 0.08, "critResist": 0.08, "stunResist": 0.07, "combatBoost": 0.07, "comboResist": 0.05, "counterRate": 0.09, "dodgeResist": 0.1, "vampireRate": 0.06, "counterResist": 0.05, "vampireResist": 0.06, "critDamageBoost": 0.06, "resistanceBoost": 0.1, "critDamageReduce": 0.09, "finalDamageBoost": 0.06, "finalDamageReduce": 0.06}}, {"id": 1771671550387.0647, "name": "天罡裤子·仙", "slot": "legs", "type": "legs", "level": 8, "stats": {"speed": 32, "defense": 35, "dodgeRate": 0.22}, "quality": "epic", "category": "equipment", "equipType": "legs", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 8}, {"id": 1771671550387.7336, "name": "灵猫", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 8, "strength": 2, "constitution": 3, "intelligence": 9}, "experience": 0, "description": "敏捷的小型焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 8, "attack": 11, "health": 103, "defense": 6, "critRate": 0.06, "stunRate": 0.1, "comboRate": 0.1, "dodgeRate": 0.05, "healBoost": 0.08, "critResist": 0.06, "stunResist": 0.09, "combatBoost": 0.08, "comboResist": 0.08, "counterRate": 0.09, "dodgeResist": 0.09, "vampireRate": 0.06, "counterResist": 0.08, "vampireResist": 0.07, "critDamageBoost": 0.06, "resistanceBoost": 0.09, "critDamageReduce": 0.08, "finalDamageBoost": 0.06, "finalDamageReduce": 0.06}}], "level": 5, "realm": "燃火期五层", "gachaPity": {"petCount": 3, "equipCount": 1}, "petEssence": 595, "realmIndex": 12, "cultivation": 38000, "spiritStones": 338000, "baseAttributes": {"speed": 40, "attack": 150, "health": 1000, "defense": 60}, "reinforceStones": 1}	0	0.00000000	338000	5	燃火期五层	2000	f	\N	0	2026-02-20 23:40:27.028843	2026-02-20 23:40:27.028843	f
3	0xfad7eb0814b6838b05191a07fb987957d50c4ca9	无名修士	{"name": "无名修士", "level": 1, "spirit": 40, "cultivation": 0, "spiritStones": 100100, "maxCultivation": 100}	0	0.00000000	100500	1	燃火期一层	0	f	2026-02-19	1	2026-02-18 10:51:03.127196	2026-02-19 12:51:17.639189	f
5	0xa40d60613f61e8546a9e3348b1f31630443485ba	无名修士	{"name": "无名修士", "spiritStones": 100000}	0	0.00000000	100000	1	燃火期一层	0	f	\N	0	2026-02-19 11:23:29.400245	2026-02-19 11:23:29.400245	f
10	0xbot0000000000000000000000000000000000b2	血影·魔尊	{"name": "药仙·白露", "items": [{"id": 1771656525094.8723, "name": "幽岚肩甲", "slot": "shoulder", "type": "shoulder", "level": 15, "stats": {"health": 131, "defense": 24, "counterRate": 0.19}, "quality": "common", "category": "equipment", "equipType": "shoulder", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 15}, {"id": 1771671516178.0571, "name": "紫电裤子", "slot": "legs", "type": "legs", "level": 6, "stats": {"speed": 15, "defense": 16, "dodgeRate": 0.11}, "quality": "common", "category": "equipment", "equipType": "legs", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 6}], "level": 35, "realm": "凝焰九重", "gachaPity": {"petCount": 1, "equipCount": 1}, "petEssence": 0, "realmIndex": 12, "cultivation": 35000, "spiritStones": 994910, "baseAttributes": {"speed": 300, "attack": 4000, "health": 25000, "defense": 1500}, "reinforceStones": 0, "dungeonTotalKills": 1, "dungeonHighestFloor": 1, "dungeonTotalRewards": 10}	0	0.00000000	994910	35	凝焰九重	500000	f	\N	0	2026-02-20 23:34:08.010864	2026-02-20 23:34:08.010864	f
11	0xbot0000000000000000000000000000000000c3	云游·散人	{"items": [{"id": 1771672463536.4858, "name": "雷鹰", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 8, "strength": 8, "constitution": 4, "intelligence": 1}, "experience": 0, "description": "雷电的猛禽", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 25, "attack": 34, "health": 325, "defense": 20, "critRate": 0.13, "stunRate": 0.13, "comboRate": 0.09, "dodgeRate": 0.12, "healBoost": 0.09, "critResist": 0.11, "stunResist": 0.14, "combatBoost": 0.13, "comboResist": 0.09, "counterRate": 0.12, "dodgeResist": 0.13, "vampireRate": 0.14, "counterResist": 0.1, "vampireResist": 0.15, "critDamageBoost": 0.1, "resistanceBoost": 0.12, "critDamageReduce": 0.08, "finalDamageBoost": 0.11, "finalDamageReduce": 0.13}}], "level": 20, "spirit": 200, "petEssence": 20, "cultivation": 500, "spiritStones": 805960, "reinforceStones": 0, "dungeonBossKills": 1, "dungeonTotalKills": 6, "dungeonHighestFloor": 100, "dungeonTotalRewards": 4010}	0	0.00000000	805960	20	凝焰四重	100000	f	\N	0	2026-02-20 23:40:14.253813	2026-02-21 06:33:36.234009	f
2	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名焰修	{"luck": 1, "name": "无名焰修", "herbs": [{"id": "1771612057477uc6pxwpvc", "name": "灵精草", "value": 15, "herbId": "spirit_grass", "quality": "uncommon", "obtainedAt": 1771612057477}, {"id": "1771612057477iafg4avep", "name": "灵精草", "value": 20, "herbId": "spirit_grass", "quality": "rare", "obtainedAt": 1771612057477}], "items": [{"id": 1771607019453.5847, "name": "青玉头部·神", "slot": "head", "type": "head", "level": 1, "stats": {"health": 218, "defense": 25, "stunResist": 0.24}, "quality": "mythic", "equipType": "head", "qualityInfo": {"name": "仙品", "color": "#e91e63", "statMod": 3, "maxStatMod": 4}, "requiredRealm": 1}, {"id": 1771607021750.559, "name": "紫霄焰杖·神", "slot": "weapon", "type": "weapon", "level": 1, "stats": {"attack": 63, "critRate": 0.26, "critDamageBoost": 0.42}, "quality": "mythic", "equipType": "weapon", "qualityInfo": {"name": "仙品", "color": "#e91e63", "statMod": 3, "maxStatMod": 4}, "requiredRealm": 1}, {"id": 1771607035657.3223, "name": "雷鹰", "star": 1, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 7, "strength": 6, "constitution": 8, "intelligence": 1}, "experience": 0, "description": "雷电的猛禽", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 29, "attack": 51, "health": 376, "defense": 18, "critRate": 0.127, "stunRate": 0.138, "comboRate": 0.161, "dodgeRate": 0.104, "healBoost": 0.115, "critResist": 0.104, "stunResist": 0.161, "combatBoost": 0.104, "comboResist": 0.184, "counterRate": 0.173, "dodgeResist": 0.184, "vampireRate": 0.15, "counterResist": 0.161, "vampireResist": 0.092, "critDamageBoost": 0.161, "resistanceBoost": 0.127, "critDamageReduce": 0.104, "finalDamageBoost": 0.138, "finalDamageReduce": 0.138}}, {"id": 1771607035657.267, "name": "混元衣服·天", "slot": "body", "type": "body", "level": 1, "stats": {"health": 183, "defense": 22, "finalDamageReduce": 0.11}, "quality": "rare", "equipType": "body", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607035657.9148, "name": "星魂焰心链·天", "slot": "necklace", "type": "necklace", "level": 1, "stats": {"health": 107, "healBoost": 0.23, "spiritRate": 0.32}, "quality": "rare", "equipType": "necklace", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607035657.0295, "name": "霸下", "star": 1, "type": "pet", "level": 1, "power": 0, "rarity": "celestial", "quality": {"agility": 7, "strength": 6, "constitution": 1, "intelligence": 9}, "experience": 0, "description": "龙之六子，形似龟，力大无穷，常背负石碑", "upgradeItems": 4, "maxExperience": 100, "combatAttributes": {"speed": 36, "attack": 53, "health": 520, "defense": 31, "critRate": 0.104, "stunRate": 0.161, "comboRate": 0.127, "dodgeRate": 0.15, "healBoost": 0.127, "critResist": 0.15, "stunResist": 0.115, "combatBoost": 0.161, "comboResist": 0.207, "counterRate": 0.207, "dodgeResist": 0.161, "vampireRate": 0.138, "counterResist": 0.15, "vampireResist": 0.115, "critDamageBoost": 0.184, "resistanceBoost": 0.15, "critDamageReduce": 0.127, "finalDamageBoost": 0.15, "finalDamageReduce": 0.138}}, {"id": 1771607035657.3733, "name": "嘲风", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "celestial", "quality": {"agility": 1, "strength": 6, "constitution": 4, "intelligence": 5}, "experience": 0, "description": "龙之三子，形似兽，喜好冒险，常立于殿角", "upgradeItems": 4, "maxExperience": 100, "combatAttributes": {"speed": 31, "attack": 51, "health": 441, "defense": 31, "critRate": 0.16, "stunRate": 0.09, "comboRate": 0.13, "dodgeRate": 0.14, "healBoost": 0.16, "critResist": 0.16, "stunResist": 0.17, "combatBoost": 0.15, "comboResist": 0.11, "counterRate": 0.09, "dodgeResist": 0.16, "vampireRate": 0.18, "counterResist": 0.16, "vampireResist": 0.11, "critDamageBoost": 0.15, "resistanceBoost": 0.14, "critDamageReduce": 0.15, "finalDamageBoost": 0.12, "finalDamageReduce": 0.1}}, {"id": 1771607035657.887, "name": "紫系腰带·天", "slot": "belt", "type": "belt", "level": 1, "stats": {"health": 119, "defense": 10, "combatBoost": 0.15}, "quality": "rare", "equipType": "belt", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607035657.843, "name": "狻犴", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "celestial", "quality": {"agility": 5, "strength": 10, "constitution": 7, "intelligence": 8}, "experience": 0, "description": "龙之五子，形似狮子，喜静好坐，常立于香炉", "upgradeItems": 4, "maxExperience": 100, "combatAttributes": {"speed": 31, "attack": 53, "health": 444, "defense": 31, "critRate": 0.13, "stunRate": 0.17, "comboRate": 0.1, "dodgeRate": 0.18, "healBoost": 0.11, "critResist": 0.18, "stunResist": 0.12, "combatBoost": 0.14, "comboResist": 0.14, "counterRate": 0.18, "dodgeResist": 0.16, "vampireRate": 0.14, "counterResist": 0.12, "vampireResist": 0.1, "critDamageBoost": 0.14, "resistanceBoost": 0.17, "critDamageReduce": 0.14, "finalDamageBoost": 0.12, "finalDamageReduce": 0.18}}, {"id": 1771607035657.76, "name": "雷鹰", "star": 2, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 3, "strength": 5, "constitution": 2, "intelligence": 3}, "experience": 0, "description": "雷电的猛禽", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 26, "attack": 41, "health": 468, "defense": 25, "critRate": 0.106, "stunRate": 0.173, "comboRate": 0.199, "dodgeRate": 0.132, "healBoost": 0.146, "critResist": 0.132, "stunResist": 0.12, "combatBoost": 0.132, "comboResist": 0.146, "counterRate": 0.173, "dodgeResist": 0.159, "vampireRate": 0.12, "counterResist": 0.146, "vampireResist": 0.185, "critDamageBoost": 0.185, "resistanceBoost": 0.185, "critDamageReduce": 0.12, "finalDamageBoost": 0.185, "finalDamageReduce": 0.132}}, {"id": 1771607035657.2698, "name": "幽命符文戒1·圣", "slot": "ring1", "type": "ring1", "level": 1, "stats": {"attack": 19, "critDamageBoost": 0.38, "finalDamageBoost": 0.18}, "quality": "legendary", "equipType": "ring1", "qualityInfo": {"name": "极品", "color": "#ff9800", "statMod": 2.5, "maxStatMod": 3.5}, "requiredRealm": 1}, {"id": 1771607035657.9792, "name": "睚眦", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "celestial", "quality": {"agility": 10, "strength": 3, "constitution": 8, "intelligence": 3}, "experience": 0, "description": "龙之次子，性格刚烈，嗜杀好斗，常刻于刀剑之上", "upgradeItems": 4, "maxExperience": 100, "combatAttributes": {"speed": 31, "attack": 41, "health": 423, "defense": 23, "critRate": 0.12, "stunRate": 0.16, "comboRate": 0.1, "dodgeRate": 0.13, "healBoost": 0.09, "critResist": 0.16, "stunResist": 0.1, "combatBoost": 0.17, "comboResist": 0.1, "counterRate": 0.17, "dodgeResist": 0.09, "vampireRate": 0.16, "counterResist": 0.1, "vampireResist": 0.1, "critDamageBoost": 0.12, "resistanceBoost": 0.17, "critDamageReduce": 0.17, "finalDamageBoost": 0.09, "finalDamageReduce": 0.11}}, {"id": 1771607035657.928, "name": "星宝焰器·天", "slot": "artifact", "type": "artifact", "level": 1, "stats": {"attack": 0, "critRate": 0.26, "comboRate": 0.32}, "quality": "rare", "equipType": "artifact", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607035657.149, "name": "玄阳衣服·仙", "slot": "body", "type": "body", "level": 1, "stats": {"health": 243, "defense": 29, "finalDamageReduce": 0.14}, "quality": "epic", "equipType": "body", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 1}, {"id": 1771607035657.1145, "name": "火凤凰", "star": 1, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 8, "strength": 1, "constitution": 3, "intelligence": 6}, "experience": 0, "description": "浴火重生的永恒之鸟", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 25, "attack": 45, "health": 408, "defense": 20, "critRate": 0.115, "stunRate": 0.104, "comboRate": 0.173, "dodgeRate": 0.161, "healBoost": 0.115, "critResist": 0.15, "stunResist": 0.115, "combatBoost": 0.115, "comboResist": 0.184, "counterRate": 0.161, "dodgeResist": 0.127, "vampireRate": 0.161, "counterResist": 0.173, "vampireResist": 0.115, "critDamageBoost": 0.173, "resistanceBoost": 0.127, "critDamageReduce": 0.173, "finalDamageBoost": 0.161, "finalDamageReduce": 0.092}}, {"id": 1771607035657.482, "name": "岩龟", "star": 1, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 3, "strength": 5, "constitution": 3, "intelligence": 1}, "experience": 0, "description": "坚不可摧的守护者", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 25, "attack": 35, "health": 399, "defense": 26, "critRate": 0.15, "stunRate": 0.161, "comboRate": 0.184, "dodgeRate": 0.115, "healBoost": 0.161, "critResist": 0.127, "stunResist": 0.104, "combatBoost": 0.115, "comboResist": 0.127, "counterRate": 0.092, "dodgeResist": 0.15, "vampireRate": 0.184, "counterResist": 0.15, "vampireResist": 0.184, "critDamageBoost": 0.127, "resistanceBoost": 0.138, "critDamageReduce": 0.138, "finalDamageBoost": 0.127, "finalDamageReduce": 0.184}}, {"id": 1771607044467.2766, "name": "蒲牢", "star": 1, "type": "pet", "level": 1, "power": 0, "rarity": "celestial", "quality": {"agility": 5, "strength": 3, "constitution": 3, "intelligence": 3}, "experience": 0, "description": "龙之四子，形似龙而小，性好鸣，常铸于钟上", "upgradeItems": 4, "maxExperience": 100, "combatAttributes": {"speed": 39, "attack": 55, "health": 501, "defense": 37, "critRate": 0.161, "stunRate": 0.196, "comboRate": 0.15, "dodgeRate": 0.127, "healBoost": 0.196, "critResist": 0.138, "stunResist": 0.173, "combatBoost": 0.115, "comboResist": 0.173, "counterRate": 0.173, "dodgeResist": 0.161, "vampireRate": 0.184, "counterResist": 0.173, "vampireResist": 0.184, "critDamageBoost": 0.184, "resistanceBoost": 0.127, "critDamageReduce": 0.138, "finalDamageBoost": 0.161, "finalDamageReduce": 0.15}}, {"id": 1771607044467.6128, "name": "星步鞋子·天", "slot": "feet", "type": "feet", "level": 1, "stats": {"speed": 15, "defense": 12, "dodgeRate": 0.11}, "quality": "rare", "equipType": "feet", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607044467.7498, "name": "玄宝焰器·天", "slot": "artifact", "type": "artifact", "level": 1, "stats": {"attack": 0, "critRate": 0.46, "comboRate": 0.43}, "quality": "rare", "equipType": "artifact", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607044467.0422, "name": "天罡裤子·天", "slot": "legs", "type": "legs", "level": 1, "stats": {"speed": 9, "defense": 14, "dodgeRate": 0.12}, "quality": "rare", "equipType": "legs", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607044467.5354, "name": "混元衣服·天", "slot": "body", "type": "body", "level": 1, "stats": {"health": 136, "defense": 20, "finalDamageReduce": 0.15}, "quality": "rare", "equipType": "body", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607044467.8093, "name": "云纱护腕·天", "slot": "wrist", "type": "wrist", "level": 1, "stats": {"defense": 8, "counterRate": 0.14, "vampireRate": 0.13}, "quality": "rare", "equipType": "wrist", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607044467.3367, "name": "螭吻", "star": 1, "type": "pet", "level": 1, "power": 0, "rarity": "celestial", "quality": {"agility": 1, "strength": 5, "constitution": 2, "intelligence": 5}, "experience": 0, "description": "龙之九子，形似鱼，能吞火，常立于屋脊", "upgradeItems": 4, "maxExperience": 100, "combatAttributes": {"speed": 37, "attack": 53, "health": 476, "defense": 29, "critRate": 0.196, "stunRate": 0.115, "comboRate": 0.15, "dodgeRate": 0.161, "healBoost": 0.138, "critResist": 0.127, "stunResist": 0.15, "combatBoost": 0.161, "comboResist": 0.196, "counterRate": 0.173, "dodgeResist": 0.161, "vampireRate": 0.161, "counterResist": 0.15, "vampireResist": 0.161, "critDamageBoost": 0.173, "resistanceBoost": 0.15, "critDamageReduce": 0.161, "finalDamageBoost": 0.15, "finalDamageReduce": 0.15}}, {"id": 1771607044467.7244, "name": "青宝焰器·天", "slot": "artifact", "type": "artifact", "level": 1, "stats": {"attack": 0, "critRate": 0.44, "comboRate": 0.37}, "quality": "rare", "equipType": "artifact", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607044467.341, "name": "紫霞鞋子·天", "slot": "feet", "type": "feet", "level": 1, "stats": {"speed": 20, "defense": 10, "dodgeRate": 0.15}, "quality": "rare", "equipType": "feet", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607044467.3816, "name": "天道符文戒2·天", "slot": "ring2", "type": "ring2", "level": 1, "stats": {"defense": 11, "resistanceBoost": 0.1, "critDamageReduce": 0.31}, "quality": "rare", "equipType": "ring2", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607044467.0835, "name": "火凤凰", "star": 3, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 8, "strength": 9, "constitution": 8, "intelligence": 5}, "experience": 0, "description": "浴火重生的永恒之鸟", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 29, "attack": 47, "health": 486, "defense": 26, "critRate": 0.199, "stunRate": 0.183, "comboRate": 0.199, "dodgeRate": 0.199, "healBoost": 0.168, "critResist": 0.213, "stunResist": 0.229, "combatBoost": 0.183, "comboResist": 0.229, "counterRate": 0.244, "dodgeResist": 0.168, "vampireRate": 0.183, "counterResist": 0.229, "vampireResist": 0.229, "critDamageBoost": 0.138, "resistanceBoost": 0.138, "critDamageReduce": 0.138, "finalDamageBoost": 0.168, "finalDamageReduce": 0.138}}, {"id": 1771607044467.147, "name": "霸下", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "celestial", "quality": {"agility": 7, "strength": 9, "constitution": 7, "intelligence": 7}, "experience": 0, "description": "龙之六子，形似龟，力大无穷，常背负石碑", "upgradeItems": 4, "maxExperience": 100, "combatAttributes": {"speed": 30, "attack": 57, "health": 443, "defense": 28, "critRate": 0.16, "stunRate": 0.1, "comboRate": 0.12, "dodgeRate": 0.17, "healBoost": 0.1, "critResist": 0.11, "stunResist": 0.12, "combatBoost": 0.17, "comboResist": 0.18, "counterRate": 0.1, "dodgeResist": 0.12, "vampireRate": 0.16, "counterResist": 0.14, "vampireResist": 0.12, "critDamageBoost": 0.18, "resistanceBoost": 0.16, "critDamageReduce": 0.17, "finalDamageBoost": 0.14, "finalDamageReduce": 0.15}}, {"id": 1771607044467.1763, "name": "紫灵焰心链·仙", "slot": "necklace", "type": "necklace", "level": 1, "stats": {"health": 207, "healBoost": 0.41, "spiritRate": 0.39}, "quality": "epic", "equipType": "necklace", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 1}, {"id": 1771607044467.3088, "name": "云踪鞋子·仙", "slot": "feet", "type": "feet", "level": 1, "stats": {"speed": 30, "defense": 13, "dodgeRate": 0.22}, "quality": "epic", "equipType": "feet", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 1}, {"id": 1771607044467.4768, "name": "冰狼", "star": 2, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 8, "strength": 6, "constitution": 1, "intelligence": 1}, "experience": 0, "description": "冰原霸主", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 29, "attack": 60, "health": 474, "defense": 29, "critRate": 0.132, "stunRate": 0.199, "comboRate": 0.159, "dodgeRate": 0.199, "healBoost": 0.146, "critResist": 0.159, "stunResist": 0.106, "combatBoost": 0.199, "comboResist": 0.185, "counterRate": 0.199, "dodgeResist": 0.12, "vampireRate": 0.185, "counterResist": 0.185, "vampireResist": 0.12, "critDamageBoost": 0.146, "resistanceBoost": 0.132, "critDamageReduce": 0.132, "finalDamageBoost": 0.106, "finalDamageReduce": 0.106}}, {"id": 1771607044467.8025, "name": "玄系腰带·天", "slot": "belt", "type": "belt", "level": 1, "stats": {"health": 125, "defense": 10, "combatBoost": 0.09}, "quality": "rare", "equipType": "belt", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607044467.8728, "name": "紫宝焰器·天", "slot": "artifact", "type": "artifact", "level": 1, "stats": {"attack": 0, "critRate": 0.23, "comboRate": 0.21}, "quality": "rare", "equipType": "artifact", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607044467.1865, "name": "狴犴", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "celestial", "quality": {"agility": 6, "strength": 4, "constitution": 6, "intelligence": 3}, "experience": 0, "description": "龙之七子，形似虎，明辨是非，常立于狱门", "upgradeItems": 4, "maxExperience": 100, "combatAttributes": {"speed": 35, "attack": 53, "health": 404, "defense": 21, "critRate": 0.11, "stunRate": 0.12, "comboRate": 0.15, "dodgeRate": 0.11, "healBoost": 0.17, "critResist": 0.14, "stunResist": 0.13, "combatBoost": 0.13, "comboResist": 0.16, "counterRate": 0.12, "dodgeResist": 0.17, "vampireRate": 0.14, "counterResist": 0.14, "vampireResist": 0.13, "critDamageBoost": 0.16, "resistanceBoost": 0.09, "critDamageReduce": 0.12, "finalDamageBoost": 0.11, "finalDamageReduce": 0.16}}, {"id": 1771607048414.113, "name": "星光裤子·仙", "slot": "legs", "type": "legs", "level": 1, "stats": {"speed": 19, "defense": 14, "dodgeRate": 0.17}, "quality": "epic", "equipType": "legs", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 1}, {"id": 1771607048414.5906, "name": "云珠焰心链·天", "slot": "necklace", "type": "necklace", "level": 1, "stats": {"health": 190, "healBoost": 0.3, "spiritRate": 0.25}, "quality": "rare", "equipType": "necklace", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607048414.1648, "name": "赤阳裤子·仙", "slot": "legs", "type": "legs", "level": 1, "stats": {"speed": 16, "defense": 25, "dodgeRate": 0.18}, "quality": "epic", "equipType": "legs", "qualityInfo": {"name": "上品", "color": "#9c27b0", "statMod": 2, "maxStatMod": 3}, "requiredRealm": 1}, {"id": 1771607048414.7751, "name": "天珠焰心链·天", "slot": "necklace", "type": "necklace", "level": 1, "stats": {"health": 173, "healBoost": 0.23, "spiritRate": 0.27}, "quality": "rare", "equipType": "necklace", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607048414.1326, "name": "睚眦", "star": 1, "type": "pet", "level": 1, "power": 0, "rarity": "celestial", "quality": {"agility": 1, "strength": 8, "constitution": 9, "intelligence": 3}, "experience": 0, "description": "龙之次子，性格刚烈，嗜杀好斗，常刻于刀剑之上", "upgradeItems": 4, "maxExperience": 100, "combatAttributes": {"speed": 40, "attack": 64, "health": 470, "defense": 33, "critRate": 0.173, "stunRate": 0.184, "comboRate": 0.196, "dodgeRate": 0.15, "healBoost": 0.127, "critResist": 0.173, "stunResist": 0.184, "combatBoost": 0.127, "comboResist": 0.207, "counterRate": 0.104, "dodgeResist": 0.138, "vampireRate": 0.161, "counterResist": 0.15, "vampireResist": 0.196, "critDamageBoost": 0.138, "resistanceBoost": 0.127, "critDamageReduce": 0.127, "finalDamageBoost": 0.15, "finalDamageReduce": 0.173}}, {"id": 1771607048414.2146, "name": "天命符文戒1·天", "slot": "ring1", "type": "ring1", "level": 1, "stats": {"attack": 16, "critDamageBoost": 0.23, "finalDamageBoost": 0.11}, "quality": "rare", "equipType": "ring1", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771607048414.402, "name": "幽岚肩甲·圣", "slot": "shoulder", "type": "shoulder", "level": 1, "stats": {"health": 160, "defense": 19, "counterRate": 0.22}, "quality": "legendary", "equipType": "shoulder", "qualityInfo": {"name": "极品", "color": "#ff9800", "statMod": 2.5, "maxStatMod": 3.5}, "requiredRealm": 1}, {"id": 1771607048414.921, "name": "冰狼", "star": 1, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 2, "strength": 9, "constitution": 9, "intelligence": 6}, "experience": 0, "description": "冰原霸主", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 30, "attack": 45, "health": 392, "defense": 24, "critRate": 0.15, "stunRate": 0.104, "comboRate": 0.115, "dodgeRate": 0.104, "healBoost": 0.104, "critResist": 0.104, "stunResist": 0.173, "combatBoost": 0.115, "comboResist": 0.173, "counterRate": 0.104, "dodgeResist": 0.161, "vampireRate": 0.15, "counterResist": 0.115, "vampireResist": 0.161, "critDamageBoost": 0.127, "resistanceBoost": 0.15, "critDamageReduce": 0.15, "finalDamageBoost": 0.138, "finalDamageReduce": 0.173}}, {"id": 1771607048414.4382, "name": "紫雷肩甲·圣", "slot": "shoulder", "type": "shoulder", "level": 1, "stats": {"health": 126, "defense": 19, "counterRate": 0.18}, "quality": "legendary", "equipType": "shoulder", "qualityInfo": {"name": "极品", "color": "#ff9800", "statMod": 2.5, "maxStatMod": 3.5}, "requiredRealm": 1}, {"id": 1771611549889.481, "name": "幻蝶", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 1, "strength": 2, "constitution": 1, "intelligence": 1}, "experience": 0, "description": "美丽的蝴蝶焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 7, "attack": 13, "health": 109, "defense": 6, "critRate": 0.08, "stunRate": 0.08, "comboRate": 0.08, "dodgeRate": 0.09, "healBoost": 0.06, "critResist": 0.06, "stunResist": 0.05, "combatBoost": 0.08, "comboResist": 0.09, "counterRate": 0.08, "dodgeResist": 0.09, "vampireRate": 0.09, "counterResist": 0.05, "vampireResist": 0.1, "critDamageBoost": 0.05, "resistanceBoost": 0.09, "critDamageReduce": 0.09, "finalDamageBoost": 0.09, "finalDamageReduce": 0.09}}, {"id": 1771611549889.8816, "name": "火凤凰", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 1, "strength": 3, "constitution": 8, "intelligence": 10}, "experience": 0, "description": "浴火重生的永恒之鸟", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 21, "attack": 35, "health": 308, "defense": 21, "critRate": 0.11, "stunRate": 0.14, "comboRate": 0.16, "dodgeRate": 0.1, "healBoost": 0.15, "critResist": 0.14, "stunResist": 0.13, "combatBoost": 0.13, "comboResist": 0.11, "counterRate": 0.14, "dodgeResist": 0.09, "vampireRate": 0.15, "counterResist": 0.12, "vampireResist": 0.1, "critDamageBoost": 0.11, "resistanceBoost": 0.15, "critDamageReduce": 0.13, "finalDamageBoost": 0.1, "finalDamageReduce": 0.15}}, {"id": 1771611549889.9678, "name": "星芒肩甲·道", "slot": "shoulder", "type": "shoulder", "level": 1, "stats": {"health": 59, "defense": 10, "counterRate": 0.1}, "quality": "uncommon", "category": "equipment", "equipType": "shoulder", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 1}, {"id": 1771611549889.8464, "name": "玄龟", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 7, "strength": 9, "constitution": 2, "intelligence": 10}, "experience": 0, "description": "擅长防御的水系焰兽", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 16, "attack": 28, "health": 201, "defense": 10, "critRate": 0.11, "stunRate": 0.11, "comboRate": 0.12, "dodgeRate": 0.11, "healBoost": 0.13, "critResist": 0.12, "stunResist": 0.1, "combatBoost": 0.11, "comboResist": 0.11, "counterRate": 0.11, "dodgeResist": 0.1, "vampireRate": 0.14, "counterResist": 0.08, "vampireResist": 0.12, "critDamageBoost": 0.11, "resistanceBoost": 0.08, "critDamageReduce": 0.08, "finalDamageBoost": 0.13, "finalDamageReduce": 0.11}}, {"id": 1771611549889.3018, "name": "云豹", "star": 1, "type": "pet", "level": 1, "power": 0, "rarity": "spiritual", "quality": {"agility": 1, "strength": 9, "constitution": 9, "intelligence": 2}, "experience": 0, "description": "敏捷的猎手", "upgradeItems": 2, "maxExperience": 100, "combatAttributes": {"speed": 18, "attack": 32, "health": 273, "defense": 13, "critRate": 0.161, "stunRate": 0.115, "comboRate": 0.092, "dodgeRate": 0.161, "healBoost": 0.104, "critResist": 0.161, "stunResist": 0.115, "combatBoost": 0.127, "comboResist": 0.104, "counterRate": 0.15, "dodgeResist": 0.115, "vampireRate": 0.104, "counterResist": 0.138, "vampireResist": 0.115, "critDamageBoost": 0.104, "resistanceBoost": 0.15, "critDamageReduce": 0.138, "finalDamageBoost": 0.104, "finalDamageReduce": 0.138}}, {"id": 1771611549889.0696, "name": "幽命符文戒1·道", "slot": "ring1", "type": "ring1", "level": 1, "stats": {"attack": 13, "critDamageBoost": 0.25, "finalDamageBoost": 0.09}, "quality": "uncommon", "category": "equipment", "equipType": "ring1", "qualityInfo": {"name": "下品", "color": "#4caf50", "statMod": 1.2, "maxStatMod": 2}, "requiredRealm": 1}, {"id": 1771611549889.4946, "name": "幽钢护腕", "slot": "wrist", "type": "wrist", "level": 1, "stats": {"defense": 8, "counterRate": 0.07, "vampireRate": 0.09}, "quality": "common", "category": "equipment", "equipType": "wrist", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 1}, {"id": 1771611549889.5383, "name": "冰狼", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 6, "strength": 3, "constitution": 10, "intelligence": 2}, "experience": 0, "description": "冰原霸主", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 23, "attack": 40, "health": 304, "defense": 17, "critRate": 0.16, "stunRate": 0.14, "comboRate": 0.12, "dodgeRate": 0.14, "healBoost": 0.12, "critResist": 0.1, "stunResist": 0.12, "combatBoost": 0.16, "comboResist": 0.12, "counterRate": 0.11, "dodgeResist": 0.12, "vampireRate": 0.1, "counterResist": 0.08, "vampireResist": 0.15, "critDamageBoost": 0.12, "resistanceBoost": 0.15, "critDamageReduce": 0.12, "finalDamageBoost": 0.11, "finalDamageReduce": 0.14}}, {"id": 1771611597010.25, "name": "草兔", "star": 0, "type": "pet", "level": 1, "power": 0, "rarity": "mortal", "quality": {"agility": 1, "strength": 1, "constitution": 1, "intelligence": 7}, "experience": 0, "description": "温顺的兔类焰兽", "upgradeItems": 1, "maxExperience": 100, "combatAttributes": {"speed": 9, "attack": 14, "health": 112, "defense": 5, "critRate": 0.06, "stunRate": 0.05, "comboRate": 0.05, "dodgeRate": 0.08, "healBoost": 0.05, "critResist": 0.1, "stunResist": 0.1, "combatBoost": 0.09, "comboResist": 0.07, "counterRate": 0.1, "dodgeResist": 0.07, "vampireRate": 0.08, "counterResist": 0.06, "vampireResist": 0.08, "critDamageBoost": 0.08, "resistanceBoost": 0.09, "critDamageReduce": 0.08, "finalDamageBoost": 0.09, "finalDamageReduce": 0.08}}, {"id": 1771611609247.6357, "name": "天珠焰心链·天", "slot": "necklace", "type": "necklace", "level": 1, "stats": {"health": 136, "healBoost": 0.32, "spiritRate": 0.18}, "quality": "rare", "category": "equipment", "equipType": "necklace", "qualityInfo": {"name": "中品", "color": "#2196f3", "statMod": 1.5, "maxStatMod": 2.5}, "requiredRealm": 1}, {"id": 1771611614666.65, "name": "岩龟", "star": 1, "type": "pet", "level": 1, "power": 0, "rarity": "mystic", "quality": {"agility": 6, "strength": 2, "constitution": 10, "intelligence": 10}, "experience": 0, "description": "坚不可摧的守护者", "upgradeItems": 3, "maxExperience": 100, "combatAttributes": {"speed": 24, "attack": 45, "health": 376, "defense": 25, "critRate": 0.092, "stunRate": 0.184, "comboRate": 0.138, "dodgeRate": 0.184, "healBoost": 0.104, "critResist": 0.127, "stunResist": 0.092, "combatBoost": 0.161, "comboResist": 0.104, "counterRate": 0.092, "dodgeResist": 0.104, "vampireRate": 0.115, "counterResist": 0.092, "vampireResist": 0.138, "critDamageBoost": 0.138, "resistanceBoost": 0.161, "critDamageReduce": 0.127, "finalDamageBoost": 0.173, "finalDamageReduce": 0.173}}, {"id": 1771671472237.8748, "name": "幽冥焰杖", "slot": "weapon", "type": "weapon", "level": 1, "stats": {"attack": 12, "critRate": 0.1, "critDamageBoost": 0.19}, "quality": "common", "category": "equipment", "equipType": "weapon", "qualityInfo": {"name": "凡品", "color": "#9e9e9e", "statMod": 1, "maxStatMod": 1.5}, "requiredRealm": 1}], "level": 1, "pills": [], "realm": "燃火期一层", "spirit": 56, "herbRate": 1, "isGMMode": false, "activePet": null, "artifacts": [], "petConfig": {"rarityMap": {"divine": {"name": "神品", "color": "#FF0000", "probability": 0.02, "essenceBonus": 50}, "mortal": {"name": "凡品", "color": "#32CD32", "probability": 0.5, "essenceBonus": 5}, "mystic": {"name": "玄品", "color": "#9932CC", "probability": 0.15, "essenceBonus": 20}, "celestial": {"name": "仙品", "color": "#FFD700", "probability": 0.08, "essenceBonus": 30}, "spiritual": {"name": "灵品", "color": "#1E90FF", "probability": 0.25, "essenceBonus": 10}}}, "isDarkMode": false, "itemsFound": 0, "petEssence": 2570, "spiritRate": 1, "alchemyRate": 1, "cultivation": 0, "isNewPlayer": true, "pillRecipes": [], "pillsCrafted": 0, "spiritStones": 788126, "activeEffects": [], "pillFragments": {}, "pillsConsumed": 0, "storageExpand": {}, "baseAttributes": {"speed": 10, "attack": 10, "health": 100, "defense": 5}, "eventTriggered": 0, "lastOnlineTime": 1771676992956, "maxCultivation": 100, "unlockedRealms": ["燃火一层"], "unlockedSkills": [], "artifactBonuses": {"speed": 0, "attack": 0, "health": 0, "defense": 0, "critRate": 0, "stunRate": 0, "comboRate": 0, "dodgeRate": 0, "healBoost": 0, "critResist": 0, "spiritRate": 1, "stunResist": 0, "combatBoost": 0, "comboResist": 0, "counterRate": 0, "dodgeResist": 0, "vampireRate": 0, "counterResist": 0, "vampireResist": 0, "critDamageBoost": 0, "cultivationRate": 1, "resistanceBoost": 0, "critDamageReduce": 0, "finalDamageBoost": 0, "finalDamageReduce": 0}, "cultivationRate": 1, "nameChangeCount": 0, "reinforceStones": 0, "wishlistEnabled": false, "activeMountBonus": {"speed_bonus": 0, "attack_bonus": 0, "health_bonus": 0, "defense_bonus": 0}, "activeTitleBonus": {"speed_bonus": 0, "attack_bonus": 0, "health_bonus": 0, "defense_bonus": 0}, "combatAttributes": {"critRate": 0, "stunRate": 0, "comboRate": 0, "dodgeRate": 0, "counterRate": 0, "vampireRate": 0}, "combatResistance": {"critResist": 0, "stunResist": 0, "comboResist": 0, "dodgeResist": 0, "counterResist": 0, "vampireResist": 0}, "dungeonBossKills": 0, "dungeonTotalRuns": 0, "explorationCount": 0, "refinementStones": 1, "autoSellQualities": [], "breakthroughCount": 0, "dungeonDeathCount": 0, "dungeonDifficulty": 1, "dungeonEliteKills": 1, "dungeonTotalKills": 9, "equippedArtifacts": {"belt": null, "body": null, "feet": null, "head": null, "legs": null, "hands": null, "ring1": null, "ring2": null, "wrist": null, "weapon": null, "artifact": null, "necklace": null, "shoulder": null}, "specialAttributes": {"healBoost": 0, "combatBoost": 0, "critDamageBoost": 0, "resistanceBoost": 0, "critDamageReduce": 0, "finalDamageBoost": 0, "finalDamageReduce": 0}, "unlockedLocations": ["新手村"], "autoReleaseRarities": [], "dungeonHighestFloor": 9, "dungeonTotalRewards": 475, "unlockedPillRecipes": 0, "totalCultivationTime": 56, "completedAchievements": [], "dungeonHighestFloor_2": 0, "dungeonHighestFloor_5": 0, "selectedWishPetRarity": null, "dungeonHighestFloor_10": 0, "dungeonLastFailedFloor": 0, "dungeonHighestFloor_100": 0, "selectedWishEquipQuality": null}	0	0.00000000	788126	1	燃火期一层	225	f	2026-02-21	2	2026-02-18 08:26:57.865876	2026-02-21 07:30:49.53173	f
1	0xadb0ecf47e175089579da5182dd7707328575909	无名修士	{"luck": 1, "name": "无名修士", "herbs": [], "items": [], "level": 1, "pills": [], "realm": "燃火期一层", "spirit": 0, "herbRate": 1, "isGMMode": false, "activePet": null, "artifacts": [], "petConfig": {"rarityMap": {"divine": {"name": "神品", "color": "#FF0000", "probability": 0.02, "essenceBonus": 50}, "mortal": {"name": "凡品", "color": "#32CD32", "probability": 0.5, "essenceBonus": 5}, "mystic": {"name": "玄品", "color": "#9932CC", "probability": 0.15, "essenceBonus": 20}, "celestial": {"name": "仙品", "color": "#FFD700", "probability": 0.08, "essenceBonus": 30}, "spiritual": {"name": "灵品", "color": "#1E90FF", "probability": 0.25, "essenceBonus": 10}}}, "isDarkMode": true, "itemsFound": 0, "petEssence": 0, "spiritRate": 1, "alchemyRate": 1, "cultivation": 0, "isNewPlayer": true, "pillRecipes": [], "pillsCrafted": 0, "spiritStones": 100095, "activeEffects": [], "pillFragments": {}, "pillsConsumed": 0, "baseAttributes": {"speed": 10, "attack": 10, "health": 100, "defense": 5}, "eventTriggered": 0, "lastOnlineTime": 0, "maxCultivation": 100, "unlockedRealms": ["燃火期一层"], "unlockedSkills": [], "artifactBonuses": {"speed": 0, "attack": 0, "health": 0, "defense": 0, "critRate": 0, "stunRate": 0, "comboRate": 0, "dodgeRate": 0, "healBoost": 0, "critResist": 0, "spiritRate": 1, "stunResist": 0, "combatBoost": 0, "comboResist": 0, "counterRate": 0, "dodgeResist": 0, "vampireRate": 0, "counterResist": 0, "vampireResist": 0, "critDamageBoost": 0, "cultivationRate": 1, "resistanceBoost": 0, "critDamageReduce": 0, "finalDamageBoost": 0, "finalDamageReduce": 0}, "cultivationRate": 1, "nameChangeCount": 0, "reinforceStones": 0, "wishlistEnabled": false, "combatAttributes": {"critRate": 0, "stunRate": 0, "comboRate": 0, "dodgeRate": 0, "counterRate": 0, "vampireRate": 0}, "combatResistance": {"critResist": 0, "stunResist": 0, "comboResist": 0, "dodgeResist": 0, "counterResist": 0, "vampireResist": 0}, "dungeonBossKills": 0, "dungeonTotalRuns": 0, "explorationCount": 0, "refinementStones": 0, "autoSellQualities": [], "breakthroughCount": 0, "dungeonDeathCount": 0, "dungeonDifficulty": 1, "dungeonEliteKills": 0, "dungeonTotalKills": 0, "equippedArtifacts": {"belt": null, "body": null, "feet": null, "head": null, "legs": null, "hands": null, "ring1": null, "ring2": null, "wrist": null, "weapon": null, "artifact": null, "necklace": null, "shoulder": null}, "specialAttributes": {"healBoost": 0, "combatBoost": 0, "critDamageBoost": 0, "resistanceBoost": 0, "critDamageReduce": 0, "finalDamageBoost": 0, "finalDamageReduce": 0}, "unlockedLocations": ["薪火村"], "autoReleaseRarities": [], "dungeonHighestFloor": 0, "dungeonTotalRewards": 0, "unlockedPillRecipes": 0, "totalCultivationTime": 0, "completedAchievements": [], "dungeonHighestFloor_2": 0, "dungeonHighestFloor_5": 0, "selectedWishPetRarity": null, "dungeonHighestFloor_10": 0, "dungeonLastFailedFloor": 0, "dungeonHighestFloor_100": 0, "selectedWishEquipQuality": null}	0	2.00000000	100000	1	燃火期一层	225	t	2026-02-18	1	2026-02-17 14:45:23.062581	2026-02-18 12:59:22.960838	f
\.


--
-- Data for Name: private_messages; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.private_messages (id, from_wallet, to_wallet, content, is_read, created_at) FROM stdin;
1	0xbot0000000000000000000000000000000000a1	0xbot0000000000000000000000000000000000c3	你好c3，这是私聊测试	t	2026-02-21 05:58:41.721007
2	0xbot0000000000000000000000000000000000a1	0xbot0000000000000000000000000000000000c3	测试非好友私聊	f	2026-02-21 05:59:18.275133
\.


--
-- Data for Name: recharge_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recharge_log (id, wallet, tx_hash, amount, spirit_stones, bonus_stones, created_at) FROM stdin;
1	0xadb0ecf47e175089579da5182dd7707328575909	0xef6fc04775f428fa0d7651239cad2d97fa83473af3fc01c304d3e732fdf08505	1.00000000	20000	10000	2026-02-17 14:49:39.38778
2	0xadb0ecf47e175089579da5182dd7707328575909	0x4b39ac61102b89c16c3b8f40612001d9e163a30cacee19cb7932ed8e04904b53	1.00000000	10000	0	2026-02-18 12:04:58.380965
\.


--
-- Data for Name: sect_members; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.sect_members (id, sect_id, wallet, role, contribution, joined_at) FROM stdin;
2	1	0xbot0000000000000000000000000000000000b2	elder	5000	2026-02-20 23:34:08.027849
4	2	0xbot0000000000000000000000000000000000c3	leader	15000	2026-02-20 23:40:07.548852
5	2	0xbot0000000000000000000000000000000000d4	elder	8000	2026-02-20 23:40:07.554083
6	2	0xbot0000000000000000000000000000000000e5	member	3000	2026-02-20 23:40:07.55552
1	1	0xbot0000000000000000000000000000000000a1	elder	10108	2026-02-20 23:34:08.021632
3	1	0x82e402b05f3e936b63a874788c73e1552657c4f7	leader	298	2026-02-20 23:36:42.249927
\.


--
-- Data for Name: sect_tasks; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.sect_tasks (id, sect_id, type, title, description, reward_contribution, reward_stones, completed_by, reset_at) FROM stdin;
4	1	weekly	宗门大比	参加宗门内部切磋大比	80	2000	["0x82e402b05f3e936b63a874788c73e1552657c4f7"]	2026-02-20 23:36:42.867
5	1	daily	弟子指导	指导新入门弟子修炼	8	150	["0xbot0000000000000000000000000000000000a1", "0x82e402b05f3e936b63a874788c73e1552657c4f7"]	2026-02-21 01:49:23.569
6	1	daily	巡山护法	巡视宗门山门，驱逐妖兽	15	300	["0x82e402b05f3e936b63a874788c73e1552657c4f7"]	2026-02-21 01:49:23.569
7	1	daily	灵田耕种	打理宗门灵田	10	200	["0x82e402b05f3e936b63a874788c73e1552657c4f7"]	2026-02-21 01:49:23.569
\.


--
-- Data for Name: sect_war_participants; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.sect_war_participants (id, war_id, sect_id, wallet, player_name, combat_power, result, damage_dealt, round_number) FROM stdin;
14	3	1	0xbot0000000000000000000000000000000000a1	剑魔·青锋	88000	lose	88000	1
16	3	2	0xbot0000000000000000000000000000000000c3	魔尊·血影	120000	win	120000	1
15	3	1	0xbot0000000000000000000000000000000000b2	药仙·白露	65000	win	65000	2
17	3	2	0xbot0000000000000000000000000000000000d4	鬼修·幽冥	75000	lose	75000	2
13	3	1	0x82e402b05f3e936b63a874788c73e1552657c4f7	无名修士	5566	lose	5566	3
18	3	2	0xbot0000000000000000000000000000000000e5	妖修·九尾	68000	win	68000	3
\.


--
-- Data for Name: sect_war_rankings; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.sect_war_rankings (id, sect_id, season, wins, losses, points, updated_at) FROM stdin;
3	2	1	1	0	3	2026-02-21 04:11:47.521316
4	1	1	0	1	1	2026-02-21 04:11:47.524673
\.


--
-- Data for Name: sect_war_rewards; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.sect_war_rewards (id, war_id, sect_id, wallet, reward_stones, reward_contribution, claimed, created_at) FROM stdin;
14	3	1	0xbot0000000000000000000000000000000000a1	1000	20	f	2026-02-21 04:11:47.513397
15	3	1	0xbot0000000000000000000000000000000000b2	1000	20	f	2026-02-21 04:11:47.51624
16	3	2	0xbot0000000000000000000000000000000000c3	5000	100	f	2026-02-21 04:11:47.517391
17	3	2	0xbot0000000000000000000000000000000000d4	5000	100	f	2026-02-21 04:11:47.518406
18	3	2	0xbot0000000000000000000000000000000000e5	5000	100	f	2026-02-21 04:11:47.519432
13	3	1	0x82e402b05f3e936b63a874788c73e1552657c4f7	1000	20	t	2026-02-21 04:11:47.511355
\.


--
-- Data for Name: sect_wars; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.sect_wars (id, challenger_sect_id, defender_sect_id, status, challenger_score, defender_score, winner_sect_id, rounds_data, started_at, finished_at, created_at) FROM stdin;
3	1	2	finished	1	2	2	[{"round": 1, "defender": {"win": true, "name": "魔尊·血影", "wallet": "0xbot0000000000000000000000000000000000c3", "combat_power": 120000}, "challenger": {"win": false, "name": "剑魔·青锋", "wallet": "0xbot0000000000000000000000000000000000a1", "combat_power": 88000}}, {"round": 2, "defender": {"win": false, "name": "鬼修·幽冥", "wallet": "0xbot0000000000000000000000000000000000d4", "combat_power": 75000}, "challenger": {"win": true, "name": "药仙·白露", "wallet": "0xbot0000000000000000000000000000000000b2", "combat_power": 65000}}, {"round": 3, "defender": {"win": true, "name": "妖修·九尾", "wallet": "0xbot0000000000000000000000000000000000e5", "combat_power": 68000}, "challenger": {"win": false, "name": "无名修士", "wallet": "0x82e402b05f3e936b63a874788c73e1552657c4f7", "combat_power": 5566}}]	2026-02-21 00:05:07.39104	2026-02-21 04:11:47.508892	2026-02-21 00:05:07.39104
4	1	2	cancelled	0	0	\N	\N	\N	\N	2026-02-21 04:11:53.420472
\.


--
-- Data for Name: sects; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.sects (id, name, description, leader_wallet, level, exp, max_members, announcement, created_at) FROM stdin;
1	天机阁	由天机阁主青锋创立，专研剑道与丹术的神秘宗门。	0xbot0000000000000000000000000000000000a1	3	7000	30	天机阁欢迎各路焰修者！	2026-02-20 23:34:08.017582
2	血魔宗	以血魔之道称霸修仙界的邪道宗门，实力强横。	0xbot0000000000000000000000000000000000c3	4	9500	30	血魔宗不欢迎弱者！	2026-02-20 23:40:07.544992
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.settings (key, value, updated_at) FROM stdin;
gacha_equip_probs	{"epic": 0.08, "rare": 0.18, "common": 0.4, "mythic": 0.005, "uncommon": 0.3, "legendary": 0.03}	2026-02-20 12:56:16.556656-05
\.


--
-- Data for Name: titles; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.titles (id, name, description, quality, color, condition_type, condition_value, attack_bonus, defense_bonus, health_bonus, created_at) FROM stdin;
6	万兽克星	击杀100只怪物	rare	#2196f3	kills	100	0.05	0	0	2026-02-18 07:28:51.503908
7	秘境探索者	通关秘境50层	epic	#9c27b0	dungeon_floor	50	0.03	0.03	0.05	2026-02-18 07:28:51.503908
8	富甲一方	拥有100万灵石	legendary	#ff9800	spirit_stones	1000000	0	0	0.1	2026-02-18 07:28:51.503908
9	社交达人	拥有30个好友	rare	#2196f3	friends	30	0	0	0.03	2026-02-18 07:28:51.503908
10	宗门之光	宗门贡献达到10000	epic	#9c27b0	contribution	10000	0.05	0.05	0.05	2026-02-18 07:28:51.503908
11	世界守护者	参与击杀世界Boss	legendary	#ff9800	boss_kill	1	0.08	0.08	0.08	2026-02-18 07:28:51.503908
1	初燃焰火	踏上修仙之路	common	#888888	level	1	0	0	0	2026-02-18 07:28:51.503908
2	铸炉有成	成功筑基	common	#4caf50	level	10	0.01	0.01	0.01	2026-02-18 07:28:51.503908
3	凝焰大成	凝结金丹	rare	#2196f3	level	30	0.03	0.03	0.03	2026-02-18 07:28:51.503908
4	焰婴出窍	元婴出窍，神通初显	epic	#9c27b0	level	50	0.05	0.05	0.05	2026-02-18 07:28:51.503908
5	渡焰真仙	渡过天劫，位列仙班	legendary	#ff9800	level	80	0.08	0.08	0.08	2026-02-18 07:28:51.503908
12	至尊焰帝	达到最高境界	mythic	#f44336	level	100	0.15	0.15	0.15	2026-02-18 07:28:51.503908
\.


--
-- Data for Name: world_bosses; Type: TABLE DATA; Schema: public; Owner: roon_user
--

COPY public.world_bosses (id, name, level, max_hp, current_hp, attack, defense, description, rewards_config, status, spawn_time, death_time, created_at) FROM stdin;
1	远古妖龙	100	1000000	991147	5000	2000	沉睡万年的远古妖龙苏醒了，它的力量足以毁灭整个焰修界！全体焰修者联手讨伐！	{"top1": 50000, "top2": 30000, "top3": 20000, "top10": 10000, "top50": 5000, "participate": 1000}	active	2026-02-18 06:36:08.164738-05	\N	2026-02-18 06:36:08.164738-05
\.


--
-- Name: admin_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.admin_logs_id_seq', 3, true);


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.announcements_id_seq', 6, true);


--
-- Name: ascension_perks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.ascension_perks_id_seq', 7, true);


--
-- Name: ascension_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.ascension_records_id_seq', 3, true);


--
-- Name: auction_bids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.auction_bids_id_seq', 4, true);


--
-- Name: auction_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.auction_history_id_seq', 3, true);


--
-- Name: auction_listings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.auction_listings_id_seq', 7, true);


--
-- Name: boss_damage_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.boss_damage_log_id_seq', 32, true);


--
-- Name: boss_rewards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.boss_rewards_id_seq', 1, false);


--
-- Name: daily_dungeon_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.daily_dungeon_entries_id_seq', 27, true);


--
-- Name: daily_dungeons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.daily_dungeons_id_seq', 4, true);


--
-- Name: equipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.equipment_id_seq', 1, true);


--
-- Name: event_claims_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_claims_id_seq', 2, true);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.events_id_seq', 6, true);


--
-- Name: friend_gifts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.friend_gifts_id_seq', 1, true);


--
-- Name: friendships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.friendships_id_seq', 4, true);


--
-- Name: leaderboard_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.leaderboard_cache_id_seq', 113, true);


--
-- Name: monthly_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.monthly_cards_id_seq', 1, false);


--
-- Name: mounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.mounts_id_seq', 5, true);


--
-- Name: pets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.pets_id_seq', 1, false);


--
-- Name: pk_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pk_records_id_seq', 1, false);


--
-- Name: player_mail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.player_mail_id_seq', 13, true);


--
-- Name: player_mounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.player_mounts_id_seq', 4, true);


--
-- Name: player_titles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.player_titles_id_seq', 12, true);


--
-- Name: players_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.players_id_seq', 13, true);


--
-- Name: private_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.private_messages_id_seq', 2, true);


--
-- Name: recharge_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recharge_log_id_seq', 2, true);


--
-- Name: sect_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.sect_members_id_seq', 6, true);


--
-- Name: sect_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.sect_tasks_id_seq', 7, true);


--
-- Name: sect_war_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.sect_war_participants_id_seq', 18, true);


--
-- Name: sect_war_rankings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.sect_war_rankings_id_seq', 4, true);


--
-- Name: sect_war_rewards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.sect_war_rewards_id_seq', 18, true);


--
-- Name: sect_wars_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.sect_wars_id_seq', 4, true);


--
-- Name: sects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.sects_id_seq', 2, true);


--
-- Name: titles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.titles_id_seq', 12, true);


--
-- Name: world_bosses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roon_user
--

SELECT pg_catalog.setval('public.world_bosses_id_seq', 1, true);


--
-- Name: admin_logs admin_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.admin_logs
    ADD CONSTRAINT admin_logs_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: ascension_perks ascension_perks_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.ascension_perks
    ADD CONSTRAINT ascension_perks_pkey PRIMARY KEY (id);


--
-- Name: ascension_records ascension_records_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.ascension_records
    ADD CONSTRAINT ascension_records_pkey PRIMARY KEY (id);


--
-- Name: auction_bids auction_bids_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.auction_bids
    ADD CONSTRAINT auction_bids_pkey PRIMARY KEY (id);


--
-- Name: auction_history auction_history_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.auction_history
    ADD CONSTRAINT auction_history_pkey PRIMARY KEY (id);


--
-- Name: auction_listings auction_listings_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.auction_listings
    ADD CONSTRAINT auction_listings_pkey PRIMARY KEY (id);


--
-- Name: boss_damage_log boss_damage_log_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.boss_damage_log
    ADD CONSTRAINT boss_damage_log_pkey PRIMARY KEY (id);


--
-- Name: boss_rewards boss_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.boss_rewards
    ADD CONSTRAINT boss_rewards_pkey PRIMARY KEY (id);


--
-- Name: daily_dungeon_entries daily_dungeon_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.daily_dungeon_entries
    ADD CONSTRAINT daily_dungeon_entries_pkey PRIMARY KEY (id);


--
-- Name: daily_dungeons daily_dungeons_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.daily_dungeons
    ADD CONSTRAINT daily_dungeons_pkey PRIMARY KEY (id);


--
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (id);


--
-- Name: event_claims event_claims_event_id_wallet_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_claims
    ADD CONSTRAINT event_claims_event_id_wallet_key UNIQUE (event_id, wallet);


--
-- Name: event_claims event_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_claims
    ADD CONSTRAINT event_claims_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: friend_gifts friend_gifts_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.friend_gifts
    ADD CONSTRAINT friend_gifts_pkey PRIMARY KEY (id);


--
-- Name: friendships friendships_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_pkey PRIMARY KEY (id);


--
-- Name: leaderboard_cache leaderboard_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard_cache
    ADD CONSTRAINT leaderboard_cache_pkey PRIMARY KEY (id);


--
-- Name: monthly_cards monthly_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_cards
    ADD CONSTRAINT monthly_cards_pkey PRIMARY KEY (id);


--
-- Name: mounts mounts_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.mounts
    ADD CONSTRAINT mounts_pkey PRIMARY KEY (id);


--
-- Name: pets pets_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.pets
    ADD CONSTRAINT pets_pkey PRIMARY KEY (id);


--
-- Name: pk_records pk_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pk_records
    ADD CONSTRAINT pk_records_pkey PRIMARY KEY (id);


--
-- Name: player_mail player_mail_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.player_mail
    ADD CONSTRAINT player_mail_pkey PRIMARY KEY (id);


--
-- Name: player_mounts player_mounts_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.player_mounts
    ADD CONSTRAINT player_mounts_pkey PRIMARY KEY (id);


--
-- Name: player_titles player_titles_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.player_titles
    ADD CONSTRAINT player_titles_pkey PRIMARY KEY (id);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: players players_wallet_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_wallet_key UNIQUE (wallet);


--
-- Name: private_messages private_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.private_messages
    ADD CONSTRAINT private_messages_pkey PRIMARY KEY (id);


--
-- Name: recharge_log recharge_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recharge_log
    ADD CONSTRAINT recharge_log_pkey PRIMARY KEY (id);


--
-- Name: recharge_log recharge_log_tx_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recharge_log
    ADD CONSTRAINT recharge_log_tx_hash_key UNIQUE (tx_hash);


--
-- Name: sect_members sect_members_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_members
    ADD CONSTRAINT sect_members_pkey PRIMARY KEY (id);


--
-- Name: sect_members sect_members_wallet_key; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_members
    ADD CONSTRAINT sect_members_wallet_key UNIQUE (wallet);


--
-- Name: sect_tasks sect_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_tasks
    ADD CONSTRAINT sect_tasks_pkey PRIMARY KEY (id);


--
-- Name: sect_war_participants sect_war_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_war_participants
    ADD CONSTRAINT sect_war_participants_pkey PRIMARY KEY (id);


--
-- Name: sect_war_rankings sect_war_rankings_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_war_rankings
    ADD CONSTRAINT sect_war_rankings_pkey PRIMARY KEY (id);


--
-- Name: sect_war_rewards sect_war_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_war_rewards
    ADD CONSTRAINT sect_war_rewards_pkey PRIMARY KEY (id);


--
-- Name: sect_wars sect_wars_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_wars
    ADD CONSTRAINT sect_wars_pkey PRIMARY KEY (id);


--
-- Name: sects sects_name_key; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sects
    ADD CONSTRAINT sects_name_key UNIQUE (name);


--
-- Name: sects sects_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sects
    ADD CONSTRAINT sects_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: titles titles_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.titles
    ADD CONSTRAINT titles_pkey PRIMARY KEY (id);


--
-- Name: world_bosses world_bosses_pkey; Type: CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.world_bosses
    ADD CONSTRAINT world_bosses_pkey PRIMARY KEY (id);


--
-- Name: idx_auction_active; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_auction_active ON public.auction_listings USING btree (status, expires_at) WHERE ((status)::text = 'active'::text);


--
-- Name: idx_auction_bids_bidder; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_auction_bids_bidder ON public.auction_bids USING btree (bidder_wallet);


--
-- Name: idx_auction_bids_listing; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_auction_bids_listing ON public.auction_bids USING btree (listing_id);


--
-- Name: idx_auction_listings_expires; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_auction_listings_expires ON public.auction_listings USING btree (expires_at);


--
-- Name: idx_auction_listings_seller; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_auction_listings_seller ON public.auction_listings USING btree (seller_wallet);


--
-- Name: idx_auction_listings_status; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_auction_listings_status ON public.auction_listings USING btree (status);


--
-- Name: idx_boss_damage_wallet; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE UNIQUE INDEX idx_boss_damage_wallet ON public.boss_damage_log USING btree (boss_id, wallet);


--
-- Name: idx_boss_rewards_wallet; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_boss_rewards_wallet ON public.boss_rewards USING btree (wallet);


--
-- Name: idx_dde_dungeon_date; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_dde_dungeon_date ON public.daily_dungeon_entries USING btree (dungeon_id, entry_date);


--
-- Name: idx_dde_wallet_date; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_dde_wallet_date ON public.daily_dungeon_entries USING btree (wallet, entry_date);


--
-- Name: idx_equipment_owner; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_equipment_owner ON public.equipment USING btree (owner_id);


--
-- Name: idx_friend_gifts_to; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_friend_gifts_to ON public.friend_gifts USING btree (to_wallet);


--
-- Name: idx_friendships_accepted; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_friendships_accepted ON public.friendships USING btree (from_wallet, to_wallet) WHERE ((status)::text = 'accepted'::text);


--
-- Name: idx_friendships_from; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_friendships_from ON public.friendships USING btree (from_wallet);


--
-- Name: idx_friendships_status; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_friendships_status ON public.friendships USING btree (status);


--
-- Name: idx_friendships_to; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_friendships_to ON public.friendships USING btree (to_wallet);


--
-- Name: idx_mail_expires; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_mail_expires ON public.player_mail USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_mail_wallet; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_mail_wallet ON public.player_mail USING btree (to_wallet, is_read);


--
-- Name: idx_mc_wallet; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mc_wallet ON public.monthly_cards USING btree (wallet);


--
-- Name: idx_pets_owner; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_pets_owner ON public.pets USING btree (owner_id);


--
-- Name: idx_pk_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pk_created ON public.pk_records USING btree (created_at DESC);


--
-- Name: idx_pk_wallet; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pk_wallet ON public.pk_records USING btree (winner_wallet);


--
-- Name: idx_pk_wallet_a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pk_wallet_a ON public.pk_records USING btree (wallet_a);


--
-- Name: idx_pk_wallet_b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pk_wallet_b ON public.pk_records USING btree (wallet_b);


--
-- Name: idx_players_combat; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_players_combat ON public.players USING btree (combat_power DESC);


--
-- Name: idx_players_combat_power; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_players_combat_power ON public.players USING btree (combat_power DESC);


--
-- Name: idx_players_level; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_players_level ON public.players USING btree (level DESC);


--
-- Name: idx_players_total_recharge; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_players_total_recharge ON public.players USING btree (total_recharge DESC);


--
-- Name: idx_players_wallet; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_players_wallet ON public.players USING btree (wallet);


--
-- Name: idx_pm_conversation; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_pm_conversation ON public.private_messages USING btree (from_wallet, to_wallet, created_at DESC);


--
-- Name: idx_pm_from; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_pm_from ON public.private_messages USING btree (from_wallet);


--
-- Name: idx_pm_read; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_pm_read ON public.private_messages USING btree (to_wallet, is_read);


--
-- Name: idx_pm_to; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_pm_to ON public.private_messages USING btree (to_wallet);


--
-- Name: idx_pm_unread; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_pm_unread ON public.private_messages USING btree (to_wallet, is_read) WHERE (is_read = false);


--
-- Name: idx_recharge_tx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recharge_tx ON public.recharge_log USING btree (tx_hash);


--
-- Name: idx_recharge_wallet; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recharge_wallet ON public.recharge_log USING btree (wallet);


--
-- Name: idx_sect_members_sect; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_sect_members_sect ON public.sect_members USING btree (sect_id);


--
-- Name: idx_sect_members_wallet; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_sect_members_wallet ON public.sect_members USING btree (wallet);


--
-- Name: idx_sect_tasks_sect; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_sect_tasks_sect ON public.sect_tasks USING btree (sect_id);


--
-- Name: idx_sect_wars_challenger; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_sect_wars_challenger ON public.sect_wars USING btree (challenger_sect_id);


--
-- Name: idx_sect_wars_defender; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_sect_wars_defender ON public.sect_wars USING btree (defender_sect_id);


--
-- Name: idx_sect_wars_status; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_sect_wars_status ON public.sect_wars USING btree (status);


--
-- Name: idx_swp_war; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_swp_war ON public.sect_war_participants USING btree (war_id);


--
-- Name: idx_swr_wallet; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_swr_wallet ON public.sect_war_rewards USING btree (wallet);


--
-- Name: idx_swrank_points; Type: INDEX; Schema: public; Owner: roon_user
--

CREATE INDEX idx_swrank_points ON public.sect_war_rankings USING btree (points DESC);


--
-- Name: leaderboard_cache_type_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX leaderboard_cache_type_uniq ON public.leaderboard_cache USING btree (type);


--
-- Name: auction_bids auction_bids_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.auction_bids
    ADD CONSTRAINT auction_bids_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.auction_listings(id);


--
-- Name: boss_damage_log boss_damage_log_boss_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.boss_damage_log
    ADD CONSTRAINT boss_damage_log_boss_id_fkey FOREIGN KEY (boss_id) REFERENCES public.world_bosses(id);


--
-- Name: boss_rewards boss_rewards_boss_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.boss_rewards
    ADD CONSTRAINT boss_rewards_boss_id_fkey FOREIGN KEY (boss_id) REFERENCES public.world_bosses(id);


--
-- Name: daily_dungeon_entries daily_dungeon_entries_dungeon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.daily_dungeon_entries
    ADD CONSTRAINT daily_dungeon_entries_dungeon_id_fkey FOREIGN KEY (dungeon_id) REFERENCES public.daily_dungeons(id);


--
-- Name: event_claims event_claims_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_claims
    ADD CONSTRAINT event_claims_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: player_mounts player_mounts_mount_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.player_mounts
    ADD CONSTRAINT player_mounts_mount_id_fkey FOREIGN KEY (mount_id) REFERENCES public.mounts(id);


--
-- Name: player_titles player_titles_title_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.player_titles
    ADD CONSTRAINT player_titles_title_id_fkey FOREIGN KEY (title_id) REFERENCES public.titles(id);


--
-- Name: sect_members sect_members_sect_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_members
    ADD CONSTRAINT sect_members_sect_id_fkey FOREIGN KEY (sect_id) REFERENCES public.sects(id) ON DELETE CASCADE;


--
-- Name: sect_tasks sect_tasks_sect_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_tasks
    ADD CONSTRAINT sect_tasks_sect_id_fkey FOREIGN KEY (sect_id) REFERENCES public.sects(id) ON DELETE CASCADE;


--
-- Name: sect_war_participants sect_war_participants_sect_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_war_participants
    ADD CONSTRAINT sect_war_participants_sect_id_fkey FOREIGN KEY (sect_id) REFERENCES public.sects(id);


--
-- Name: sect_war_participants sect_war_participants_war_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_war_participants
    ADD CONSTRAINT sect_war_participants_war_id_fkey FOREIGN KEY (war_id) REFERENCES public.sect_wars(id);


--
-- Name: sect_war_rankings sect_war_rankings_sect_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_war_rankings
    ADD CONSTRAINT sect_war_rankings_sect_id_fkey FOREIGN KEY (sect_id) REFERENCES public.sects(id);


--
-- Name: sect_war_rewards sect_war_rewards_sect_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_war_rewards
    ADD CONSTRAINT sect_war_rewards_sect_id_fkey FOREIGN KEY (sect_id) REFERENCES public.sects(id);


--
-- Name: sect_war_rewards sect_war_rewards_war_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_war_rewards
    ADD CONSTRAINT sect_war_rewards_war_id_fkey FOREIGN KEY (war_id) REFERENCES public.sect_wars(id);


--
-- Name: sect_wars sect_wars_challenger_sect_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_wars
    ADD CONSTRAINT sect_wars_challenger_sect_id_fkey FOREIGN KEY (challenger_sect_id) REFERENCES public.sects(id);


--
-- Name: sect_wars sect_wars_defender_sect_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_wars
    ADD CONSTRAINT sect_wars_defender_sect_id_fkey FOREIGN KEY (defender_sect_id) REFERENCES public.sects(id);


--
-- Name: sect_wars sect_wars_winner_sect_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roon_user
--

ALTER TABLE ONLY public.sect_wars
    ADD CONSTRAINT sect_wars_winner_sect_id_fkey FOREIGN KEY (winner_sect_id) REFERENCES public.sects(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO roon_user;


--
-- Name: TABLE announcements; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.announcements TO roon_user;


--
-- Name: SEQUENCE announcements_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.announcements_id_seq TO roon_user;


--
-- Name: TABLE event_claims; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.event_claims TO roon_user;


--
-- Name: SEQUENCE event_claims_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.event_claims_id_seq TO roon_user;


--
-- Name: TABLE events; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.events TO roon_user;


--
-- Name: SEQUENCE events_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.events_id_seq TO roon_user;


--
-- Name: TABLE leaderboard_cache; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.leaderboard_cache TO roon_user;


--
-- Name: SEQUENCE leaderboard_cache_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.leaderboard_cache_id_seq TO roon_user;


--
-- Name: TABLE monthly_cards; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.monthly_cards TO roon_user;


--
-- Name: SEQUENCE monthly_cards_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.monthly_cards_id_seq TO roon_user;


--
-- Name: TABLE pk_records; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pk_records TO roon_user;


--
-- Name: SEQUENCE pk_records_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.pk_records_id_seq TO roon_user;


--
-- Name: TABLE players; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.players TO roon_user;


--
-- Name: SEQUENCE players_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.players_id_seq TO roon_user;


--
-- Name: TABLE recharge_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.recharge_log TO roon_user;


--
-- Name: SEQUENCE recharge_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.recharge_log_id_seq TO roon_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO roon_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO roon_user;


--
-- PostgreSQL database dump complete
--

\unrestrict f95Ud05VRJkckMDJPsWlFb08z6U4sRb9rsLsdFf5VL0SISIhKw5S03Mhj1cUzQY

